import React,{Component} from 'react'

class HomeComponent extends Component{

    render(){
        return(
            <div className="user-dashboard">
                <h1>Welcome, <span >Dipankar Dutta</span></h1>
                <div className="row">
                </div>
            </div>
        )
    }
}

export default HomeComponent;