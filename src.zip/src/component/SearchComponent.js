import React,{Component} from 'react'

class SearchComponent extends Component{

    render(){
        return(
            <div>This is Search component</div>
        )
    }
}

export default SearchComponent;