
export function updateAppState(text) { 
    this.setState(text)
}