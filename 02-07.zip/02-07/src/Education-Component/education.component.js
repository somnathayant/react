import React from 'react';
import { Redirect } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import FooterComponent from '../Footer/Footer.component';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import MenubarComponent from '../Menubar-Component/Menubar.component';
import { TabView, TabPanel } from 'primereact/tabview';
import { Panel } from 'primereact/panel';
import { DataTable } from 'primereact/datatable';
import { FileUpload } from 'primereact/fileupload';
import { Column } from 'primereact/column';
import { Dialog } from 'primereact/dialog';
import { Calendar } from 'primereact/calendar';
import EducationService from '../services/education-service';
class EducationComponent extends React.Component {

    constructor(props) {
        super(props);
        this.educationService = new EducationService();
        this.onAdd = this.onAdd.bind(this);
        this.onHide = this.onHide.bind(this);
        this.onUpdate = this.onUpdate.bind(this);
        this.actionOnUpdateTemplate = this.actionOnUpdateTemplate.bind(this);
        this.onDelete = this.onDelete.bind(this);
        this.actionOnDeleteTemplate = this.actionOnDeleteTemplate.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.handleDegreeChange = this.handleDegreeChange.bind(this);
        this.handleSchoolChange = this.handleSchoolChange.bind(this);
        this.handleFieldOfStudyChange = this.handleFieldOfStudyChange.bind(this);
        this.handleStartDateChange = this.handleStartDateChange.bind(this);
        this.handleEndDateChange = this.handleEndDateChange.bind(this);
        this.state = {
            visibleOn: false,
            visibleOff: true,
            displayResponsive: false,
            displayAdd: false,
            educations: [],
            candidateId: '',
            id: '',
            degree: '',
            school: '',
            fieldOfStudy: '',
            startDate: '',
            endDate: ''
        };
    }

    //handle Change methods
    handleDegreeChange(e) {
        this.setState({ degree: e.target.value });
    }
    handleSchoolChange(e) {
        this.setState({ school: e.target.value });
    } handleFieldOfStudyChange(e) {
        this.setState({ fieldOfStudy: e.target.value });
    } handleStartDateChange(e) {
        this.setState({ startDate: e.target.value });
    } handleEndDateChange(e) {
        this.setState({ endDate: e.target.value });
    }

    //loading method
    componentDidMount() {
        this.educationService.retrieveEducations().then(educations => {
            this.setState({
                educations: educations
            });
        });
    }
    //method to display panel
    onAdd(name) {
        alert("add");
        this.setState({
            degree: '',
            school: '',
            fieldOfStudy: '',
            startDate: '',
            endDate: ''
        });
        let state = {
            [`${name}`]: true
        };

        this.setState(state);
    }

    //submit method
    onSubmit = (event) => {
        event.preventDefault();

        alert(this.state.degree);
        alert(new Date(this.state.startDate).toLocaleDateString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' })); // 08/19/2020 (month and day with two digits)

        this.onHide('displayAdd');
        this.onHide('displayResponsive');
    }

    //method to display panel
    onUpdate(name, rowData) {
        alert(rowData.candidateId);
        alert(rowData.id);
        this.setState({
            candidateId: this.state.educations[0].candidateId,
            id: this.state.educations[0].id,
            degree: this.state.educations[0].degree,
            school: this.state.educations[0].school,
            fieldOfStudy: this.state.educations[0].fieldOfStudy,
            startDate: new Date(this.state.educations[0].startDate),
            endDate: new Date(this.state.educations[0].endDate),
        });
        let state = {
            [`${name}`]: true
        };

        this.setState(state);
    }
    //hide panel
    onHide(name) {
        this.setState({
            [`${name}`]: false
        });
    }
    //shows pencil icon in datatable for update
    actionOnUpdateTemplate(rowData) {
        // alert(rowData.candidateId);
        return (
            <React.Fragment>
                <Button icon="pi pi-pencil" onClick={() => this.onUpdate('displayResponsive', rowData)} />
            </React.Fragment>
        );
    }
    onDelete(rowData) {
        alert(rowData.candidateId + "d");

    }
    //shows trash icon in datatable for delete
    actionOnDeleteTemplate(rowData) {
        // alert(rowData.candidateId);
        return (
            <React.Fragment>
                <Button icon="pi pi-trash" onClick={() => this.onDelete(rowData)} />
            </React.Fragment>
        );
    }

    render() {
        return (
            <div>
                <Button icon="pi pi-save" onClick={() => this.onAdd('displayAdd')} />
                <hr></hr>
                <Dialog header="Add Education" visible={this.state.displayAdd} onHide={() => this.onHide('displayAdd')} breakpoints={{ '960px': '75vw' }} style={{ width: '50vw' }} >
                    <form onSubmit={this.onSubmit}>
                        <div className="p-grid">
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="candidate-id" disabled="true" value={this.state.candidateId} />
                                    <label htmlFor="candidate-id">Candidate Id</label>

                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="degree" value={this.state.degree} onChange={this.handleDegreeChange} />
                                    <label htmlFor="degree">Degree</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="school" value={this.state.school} onChange={this.handleSchoolChange} />
                                    <label htmlFor="school">School</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="fieldOfStudy" value={this.state.fieldOfStudy} onChange={this.handleFieldOfStudyChange} />
                                    <label htmlFor="fieldOfStudy">Field Of Study</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <Calendar id="startDate" dateFormat="mm/dd/yy" placeholder="Start Date(mm/dd/yy)" value={this.state.startDate} onChange={this.handleStartDateChange}></Calendar>
                                    <label htmlFor="startDate">Start Date</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <Calendar id="endDate" dateFormat="mm/dd/yy" placeholder="End Date(mm/dd/yy)" value={this.state.endDate} onChange={this.handleEndDateChange}></Calendar>
                                    <label htmlFor="endDate">End Date</label>
                                </span>
                            </div>
                            <div className="p-col-2 p-m-2">
                                <span className="p-float-label">
                                    <Button label="Submit" type="submit" icon="pi pi-save" className="p-button-info p-button-rounded" />
                                </span>
                            </div>

                        </div>
                    </form>
                </Dialog>

                <Dialog header="Update Education" visible={this.state.displayResponsive} onHide={() => this.onHide('displayResponsive')} breakpoints={{ '960px': '75vw' }} style={{ width: '50vw' }} >
                    <form onSubmit={this.onSubmit}>
                        <div className="p-grid">
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="candidate-id" disabled="true" value={this.state.candidateId} />
                                    <label htmlFor="candidate-id">Candidate Id</label>
                                    <InputText id="id" hidden="true" value={this.state.id} />
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="degree" value={this.state.degree} onChange={this.handleDegreeChange} />
                                    <label htmlFor="degree">Degree</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="school" value={this.state.school} onChange={this.handleSchoolChange} />
                                    <label htmlFor="school">School</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="fieldOfStudy" value={this.state.fieldOfStudy} onChange={this.handleFieldOfStudyChange} />
                                    <label htmlFor="fieldOfStudy">Field Of Study</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <Calendar id="startDate" dateFormat="mm/dd/yy" placeholder="Start Date(mm/dd/yy)" value={this.state.startDate} onChange={this.handleStartDateChange}></Calendar>
                                    <label htmlFor="startDate">Start Date</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <Calendar id="endDate" dateFormat="mm/dd/yy" placeholder="End Date(mm/dd/yy)" value={this.state.endDate} onChange={this.handleEndDateChange}></Calendar>
                                    <label htmlFor="endDate">End Date</label>
                                </span>
                            </div>
                            <div className="p-col-2 p-m-2">
                                <span className="p-float-label">
                                    <Button label="Submit" type="submit" icon="pi pi-save" className="p-button-info p-button-rounded" />
                                </span>
                            </div>

                        </div>
                    </form>
                </Dialog>

                <Panel header="Educations" toggleable>
                    <div className="p-grid">
                        <div className="p-col-10 p-m-2">
                            <DataTable value={this.state.educations}>
                                <Column field="degree" header="Degree"></Column>
                                <Column field="school" header="School"></Column>
                                <Column field="fieldOfStudy" header="Field Of Study"></Column>
                                <Column field="startDate" header="Start Date"></Column>
                                <Column field="endDate" header="End Date"></Column>

                                <Column field="candidateId" body={this.actionOnUpdateTemplate} header="Update"></Column>
                                <Column field="candidateId" field="id" body={this.actionOnDeleteTemplate} header="Delete"></Column>

                            </DataTable>
                        </div>

                    </div>
                </Panel>

            </div>
        );
    }
}
export default withRouter(EducationComponent);
