import React from 'react';
import MenubarComponent from '../Menubar-Component/Menubar.component';

import {
  Card, CardImg, CardText, CardBody,
  CardTitle, CardSubtitle, Button
} from 'reactstrap';
var DatePicker = require("reactstrap-date-picker");
export default class CandidateComponent extends React.Component {

  constructor(props) {
    super(props);
    this.onSubmit = this.onSubmit.bind(this);
    this.onChangeAliasName=this.onChangeAliasName.bind(this);
    this.onChangeFirstName=this.onChangeFirstName.bind(this);
    this.onChangeMiddleName=this.onChangeMiddleName.bind(this);
    this.onChangeLastName=this.onChangeLastName.bind(this);
    this.onChangeProfileTitle=this.onChangeProfileTitle.bind(this);
    this.onChangeInterViewMode=this.onChangeInterViewMode.bind(this);
    this.onChangeInterviewStatuses=this.onChangeInterviewStatuses.bind(this);
    this.onChangePassword=this.onChangePassword.bind(this);
    this.onChangeWorkExperience=this.onChangeWorkExperience.bind(this);
    this.onChangeReleventExperience=this.onChangeReleventExperience.bind(this);
    this.onChangeComment=this.onChangeComment.bind(this);
    this.onChangeEmail=this.onChangeEmail.bind(this);
    this.onChangeAlternateEmail=this.onChangeAlternateEmail.bind(this);
    this.onChangeCoverLetter=this.onChangeCoverLetter.bind(this);
    this.onChangeSummary=this.onChangeSummary.bind(this);
    this.onChangeBirthDate=this.onChangeBirthDate.bind(this);
    


    this.state = {
      aliasName: '',
      firstName: '',
      middleName: '',
      lastName: '',
      profileTitle: '',
      interViewMode: '',
      interviewStatuses: '',
      birthDate: '',
      password: '',
      workExperience: '',
      releventExperience: '',
      comment: '',
      hiringType: '',
      email: '',
      alternateEmail: '',
      
      coverLetter: '',
      summary: ''

    }

  }
//method registering
onChangeAliasName(e) {
  this.setState({
    aliasName: e.target.value
  });
}

onChangeFirstName(e) {
  this.setState({
    firstName: e.target.value
  });
}
onChangeMiddleName(e) {
  this.setState({
    middleName: e.target.value
  });
}
onChangeLastName(e) {
  this.setState({
    lastName: e.target.value
  });
}
onChangeProfileTitle(e) {
  this.setState({
    profileTitle: e.target.value
  });
}
onChangeInterViewMode(e) {
  this.setState({
    interViewMode: e.target.value
  });
}
onChangeInterviewStatuses(e) {
  this.setState({
    interviewStatuses: e.target.value
  });
}
onChangePassword(e) {
  this.setState({
    password: e.target.value
  });
}
onChangeWorkExperience(e) {
  this.setState({
    workExperience: e.target.value
  });
}
onChangeReleventExperience(e) {
  this.setState({
    releventExperience: e.target.value
  });
}
onChangeComment(e) {
  this.setState({
    comment: e.target.value
  });
}
onChangeEmail(e) {
  this.setState({
    email: e.target.value
  });
}
onChangeAlternateEmail(e) {
  this.setState({
    alternateEmail: e.target.value
  });
}
onChangeCoverLetter(e) {
  this.setState({
    coverLetter: e.target.value
  });
}
onChangeSummary(e) {
  this.setState({
    summary: e.target.value
  });
}
onChangeBirthDate(e) {
  this.setState({
    birthDate: new Date(e.target.value)
  });
}
  onSubmit(e) {
    
  }
  render() {

    return (
      <div>
        <MenubarComponent></MenubarComponent>
        <br></br>
        <div class="container-fluid">

          <Card>
            <CardBody>
              <CardTitle tag="h5">Candidate Information </CardTitle>
              <CardText>
                <form onClick={this.onSubmit}>
                  <div class="row">
                  <div class="col-sm-4"> <input type="text" class="form-control" id="aliasName" placeholder="Candidate Alias Name"
                      value={this.state.aliasName}
                      onChange={this.onChangeAliasName} /></div>
                 
                    <div class="col-sm-4"> <input type="text" class="form-control" id="first-name" placeholder="Candidate First Name"
                      value={this.state.firstName}
                      onChange={this.onChangeFirstName} /></div>
                    <div class="col-sm-4"> <input type="text" class="form-control" id="middle-name" placeholder="Candidate Middle Name"
                      value={this.state.middleName}
                      onChange={this.onChangeMiddleName} />
                    </div>
                    <hr></hr>
                    <div class="col-sm-4"> <input type="text" class="form-control" id="last-name" placeholder="Candidate Last Name"
                      value={this.state.lastName}
                      onChange={this.onChangeLastName} /></div>
                    
                    <div class="col-sm-4"> <input type="text" class="form-control" id="profile-title" placeholder="Candidate Profile Title " 
                    value={this.state.profileTitle}
                      onChange={this.onChangeProfileTitle} /></div>
                    <div class="col-sm-4"> <input type="text" class="form-control" id="interViewMode" placeholder="Candidate InterView Mode" 
                    value={this.state.interViewMode}
                      onChange={this.onChangeInterViewMode} /></div>
                      <hr></hr>
                    <div class="col-sm-4"> <input type="text" class="form-control" id="interviewStatuses" placeholder="Candidate Interview Statuses" 
                    value={this.state.interviewStatuses}
                      onChange={this.onChangeInterviewStatuses} /></div>
                    
                    <div class="col-sm-4"> <input type="text" class="form-control" id="password" placeholder="Candidate password" 
                    value={this.state.password}
                      onChange={this.onChangePassword} /></div>

                    <div class="col-sm-4"> <input type="text" class="form-control" id="workExperience" placeholder="Candidate Work Experience" 
                    value={this.state.workExperience}
                      onChange={this.onChangeWorkExperience} /></div>
                    <hr></hr>
                    <div class="col-sm-4"> <input type="text" class="form-control" id="releventExperience" placeholder="Candidate Relevent Experience"
                     value={this.state.ReleventExperience}
                      onChange={this.onChangeReleventExperience} /></div>
                   
                    <div class="col-sm-4"> <input type="text" class="form-control" id="comment" placeholder="Candidate Interview comment" 
                    value={this.state.comment}
                      onChange={this.onChangeComment} /></div>
                    <div class="col-sm-4"> <input type="text" class="form-control" id="hiringType" placeholder="Candidate Hiring Type" 
                    value={this.state.hiringType}
                      onChange={this.onChangeHiringType} /></div>
                      <hr></hr>

                    <div class="col-sm-4"> <input type="text" class="form-control" id="email" placeholder="Candidate Email" 
                    value={this.state.email}
                      onChange={this.onChangeEmail} /></div>
                    
                    <div class="col-sm-4"> <input type="text" class="form-control" id="alternateEmail" placeholder="Candidate Alternate Email " 
                    value={this.state.alternateEmail}
                      onChange={this.onChangeAlternateEmail} /></div>
                    <div class="col-sm-4"> <input type="text" class="form-control" id="coverLetter" placeholder="Candidate Cover Letter" 
                    value={this.state.coverLetter}
                      onChange={this.onChangeCoverLetter} /></div>
                      <hr></hr>
                    <div class="col-sm-4"> <input type="text" class="form-control" id="summary" placeholder="Candidate Summary" 
                    value={this.state.summary}
                      onChange={this.onChangeSummary} /></div>
                 
                    <div class="col-sm-4"> <DatePicker dateFormat="MM/DD/YYYY" value={this.state.birthDate}
                      onChange={this.onChangeBirthDate} /></div>
                    <div class="col-sm-4">
                      <div className="form-group">
                        <input type="submit" value="Save" className="btn btn-primary" />
                      </div>
                    </div>
                  </div>
                </form>
              </CardText>

            </CardBody>
          </Card>
        </div>
      </div>
    );
  }
}








