class CandidateService{





    
}