 class EducationService {


    constructor() {

        this.educations=[
            {
                "candidateId": "112e013f-4145-44ec-a5c0-1cc35d9dc764",
                "id": "032011ca-4584-4d54-b366-0bb34d137928",
                "degree": "DS",
                "school": "University of Chicago",
                "fieldOfStudy": "IT",
                "startDate": "01/01/2020",
                "endDate": "01/01/2021"
            },{
                "candidateId": "112e013f-4145-44ec-a5c0-1cc35d9dc764",
                "id": "032011ca-4584-4d54-b366-0bb34d137928",
                "degree": "DS",
                "school": "University of Chicago",
                "fieldOfStudy": "IT",
                "startDate": "01/01/2020",
                "endDate": "01/01/2021"
            }
        ];

    }
    async retrieveEducations() {
              return Promise.resolve(this.educations);
          }
}
export default EducationService;