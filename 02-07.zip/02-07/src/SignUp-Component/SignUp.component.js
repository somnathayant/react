import React from 'react';
import FooterComponent from '../Footer/Footer.component';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import { TabView, TabPanel } from 'primereact/tabview';
import { Panel } from 'primereact/panel';
import { Calendar } from 'primereact/calendar';
import { Password } from 'primereact/password';
import { Dropdown } from 'primereact/dropdown';
import WelcomeComponent from '../Welcome-Component/Welcome.component';
import axios from 'axios';

export default class SignUpComponent extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            interViewMode: null,
            interviewStatus: null,
            hiringType: null
        };
        this.interViewModes = [
            { "name": 'Skype' },
            { "name": 'Zoom' },
            { "name": 'Webex' },
            { "name": 'F2F' },
            { "name": 'N/A' }
        ];
        this.interviewStatuses = [
            { "name": "Scheduled" },
            { "name": "PO Received" },
            { "name": "Project Started" },
            { "name": "Rejected" },
            { "name": "Pending" },
            { "name": 'N/A' }
        ];
        this.hiringTypes = [
            { "name": "W2" },
            { "name": "C2C" },
            { "name": "C2H" },
        ]

        this.interViewModeChange = this.interViewModeChange.bind(this);
        this.interviewStatusesChange = this.interviewStatusesChange.bind(this);
        this.hiringTypesChange = this.hiringTypesChange.bind(this);
    }

    componentDidMount() {
       
        axios.post("http://localhost:8080/oauth/token",{
                   client_id: 'somnath',
                    client_secret: 'somnath-demo',
                    grant_type: 'password',
                    username: 'javainuse-user',
                    password: 'javainuse-pass'
                })
                    .then(res => {
                        alert(res.data.access_token);
                    }).catch(er => {
                       
                    });
            }
    

    hiringTypesChange(e) {
        this.setState({ hiringType: e.value });
    }
    interViewModeChange(e) {
        this.setState({ interViewMode: e.value });
    }

    interviewStatusesChange(e) {
        this.setState({ interviewStatus: e.value });

    }

    onSubmit = () => {

        this.props.history.push('/CandidateProfileComponent');
    }

    render() {
        return (
            <div>
                <WelcomeComponent></WelcomeComponent>
                <div class="container-fluid" id="signUp-container">
                    <div id="registration-box-signUp" >
                        <div id="signUp-heading">
                            <center> <img src="/intello_logo.png" alt="intello Group Inc.." width="150" height="50" /></center>
                        </div>
                        <form onSubmit={this.onSubmit}>
                            <Panel header="Please Register">

                                <TabView >
                                    <TabPanel header="Personal Data">
                                        <div className="p-grid">
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">

                                                    <InputText id="firstName" type="text" />
                                                    <label htmlFor="firstName">First Name</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">

                                                    <InputText id="middleName" type="text" />
                                                    <label htmlFor="middleName">Middle Name</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">

                                                    <InputText id="lastName" type="text" />
                                                    <label htmlFor="lastName">Last Name</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">

                                                <Calendar id="birth-date" dateFormat="mm/dd/yy" placeholder="Birth Date"></Calendar>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <Password id="password" placeholder="Password" />
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <Password id="confirmPassword" placeholder=" Confirm Password" />
                                            </div>
                                        </div>

                                    </TabPanel>
                                    <TabPanel header="Professional Data">
                                        <div className="p-grid">
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="profileTitle" />
                                                    <label htmlFor="profileTitle">profileTitle</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <Dropdown value={this.state.interViewMode} options={this.interViewModes} onChange={this.interViewModeChange} optionLabel="name" placeholder="Interview Mode" />
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <Dropdown value={this.state.interviewStatus} options={this.interviewStatuses} onChange={this.interviewStatusesChange} optionLabel="name" placeholder="InterView Status" />
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="workExperience" />
                                                    <label htmlFor="workExperience">workExperience</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="releventExperience" />
                                                    <label htmlFor="releventExperience">releventExperience</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="comment" />
                                                    <label htmlFor="comment">comment</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <Dropdown value={this.state.hiringType} options={this.hiringTypes} onChange={this.hiringTypesChange} optionLabel="name" placeholder="Hiring Type" />
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="email" />
                                                    <label htmlFor="email">email</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="coverLetter" />
                                                    <label htmlFor="coverLetter">coverLetter</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="summary" />
                                                    <label htmlFor="summary">summary</label>
                                                </span>
                                            </div>
                                        </div>

                                    </TabPanel>

                                </TabView>
                                <Button label="Submit" className="p-button-info p-button-rounded" />

                            </Panel>
                        </form>
                    </div>

                    <FooterComponent></FooterComponent>
                </div>
            </div>

        );
    }
}








