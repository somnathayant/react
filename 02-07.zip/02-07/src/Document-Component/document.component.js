import React from 'react';
import { Redirect } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import FooterComponent from '../Footer/Footer.component';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import MenubarComponent from '../Menubar-Component/Menubar.component';
import { TabView, TabPanel } from 'primereact/tabview';
import { Panel } from 'primereact/panel';
import { DataTable } from 'primereact/datatable';
import { FileUpload } from 'primereact/fileupload';
import { Column } from 'primereact/column';
class DocumentComponent extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            products: [
              
            ]
        };

    }

    render() {
        return (
            <div>
                <Panel header="Documents" toggleable>
                    <div className="p-grid">
                        <div className="p-col-10 p-m-2">
                            <DataTable value={this.state.products} showGridlines>
                                <Column field="name" header="Document Name"></Column>
                                <Column field="download" header="Download Link"></Column>
                                <Column field="upload date" header="Upload Date"></Column>

                            </DataTable>
                        </div>
                    </div>
                </Panel>
                <Panel header="Add Document" >
                    <div className="p-grid">
                        <div className="p-col-2 p-m-2">
                        <FileUpload name="documentUpload" url="" mode="basic" multiple />
                        </div>
                    </div>
                </Panel>
            </div>
        );
    }
}
export default withRouter(DocumentComponent);
