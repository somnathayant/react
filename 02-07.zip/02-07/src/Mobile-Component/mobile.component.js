import React from 'react';
import { Redirect } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import FooterComponent from '../Footer/Footer.component';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import MenubarComponent from '../Menubar-Component/Menubar.component';
import { TabView, TabPanel } from 'primereact/tabview';
import { Panel } from 'primereact/panel';

class MobileComponent extends React.Component {

    constructor(props) {
        super(props);

    }

    render() {
        return (
            <div>
                <Panel header="Mobile" toggleable>
                    <div className="p-grid">
                        <div className="p-col-2 p-m-2">
                            <span className="p-float-label">
                                <InputText id="candidate-id" />
                                <label htmlFor="candidate-id">Candidate Id</label>
                            </span>
                        </div>
                        <div className="p-col-2 p-m-2">
                            <span className="p-float-label">
                                <InputText id="candidate-id" />
                                <label htmlFor="candidate-id">Candidate Id</label>
                            </span>
                        </div>
                        <div className="p-col-2 p-m-2">
                            <span className="p-float-label">
                                <InputText id="candidate-id" />
                                <label htmlFor="candidate-id">Candidate Id</label>
                            </span>
                        </div>
                        <div className="p-col-2 p-m-2">
                            <span className="p-float-label">
                                <InputText id="candidate-id" />
                                <label htmlFor="candidate-id">Candidate Id</label>
                            </span>
                        </div>
                        <div className="p-col-2 p-m-2">
                            <span className="p-float-label">
                                <Button label="Update" icon="pi pi-save" className="p-button-info p-button-rounded" />
                            </span>
                        </div>
                    </div>
                </Panel>
                <Panel header="Add Mobile" >
                    <div className="p-grid">
                        <div className="p-col-2 p-m-2">
                            <span className="p-float-label">
                                <InputText id="candidate-id" />
                                <label htmlFor="candidate-id">Candidate Id</label>
                            </span>
                        </div>
                        <div className="p-col-2 p-m-2">
                            <span className="p-float-label">
                                <InputText id="candidate-id" />
                                <label htmlFor="candidate-id">Candidate Id</label>
                            </span>
                        </div>
                        <div className="p-col-2 p-m-2">
                            <span className="p-float-label">
                                <InputText id="candidate-id" />
                                <label htmlFor="candidate-id">Candidate Id</label>
                            </span>
                        </div>
                        <div className="p-col-2 p-m-2">
                            <span className="p-float-label">
                                <InputText id="candidate-id" />
                                <label htmlFor="candidate-id">Candidate Id</label>
                            </span>
                        </div>
                        <div className="p-col-2 p-m-2">
                            <span className="p-float-label">
                                <Button label="Update" icon="pi pi-save" className="p-button-info p-button-rounded" />
                            </span>
                        </div>

                    </div>
                </Panel>
            </div>
        );
    }
}
export default withRouter(MobileComponent);

