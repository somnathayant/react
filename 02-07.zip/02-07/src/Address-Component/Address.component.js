import React from 'react';
import { Redirect } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import FooterComponent from '../Footer/Footer.component';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import MenubarComponent from '../Menubar-Component/Menubar.component';
import { TabView, TabPanel } from 'primereact/tabview';
import { Panel } from 'primereact/panel';
import { DataTable } from 'primereact/datatable';
import { FileUpload } from 'primereact/fileupload';
import { Column } from 'primereact/column';
import { Dialog } from 'primereact/dialog';
class AddressComponent extends React.Component {

    constructor(props) {
        super(props);

        this.onAdd = this.onAdd.bind(this);
        this.onAddSubmit = this.onAddSubmit.bind(this);
        this.onUpdateSubmit = this.onUpdateSubmit.bind(this);
        this.onHide = this.onHide.bind(this);
        this.onUpdate = this.onUpdate.bind(this);
        this.actionOnUpdateTemplate = this.actionOnUpdateTemplate.bind(this);
        this.onDelete = this.onDelete.bind(this);
        this.actionOnDeleteTemplate = this.actionOnDeleteTemplate.bind(this);
        this.state = {
            visibleOn: false,
            visibleOff: true,
            displayResponsive: false,
            displayAdd: false,
            products: [
                {
                    "candidateId": "can1",
                    "addressId": "ca279476-721a-4a8a-ab31-1da13079ae5c",
                    "city": "india",
                    "state": "WB"

                },

                {
                    "candidateId": "can3",
                    "addressId": "ff20d800-dcce-485c-a5e3-a55894e90d76",
                    "city": "Asansol",
                    "state": "WB"

                }

            ]
        };
    }

    onAdd(name) {
        alert("add");
        let state = {
            [`${name}`]: true
        };

        this.setState(state);
    }
    onAddSubmit() {
        this.onHide('displayAdd');
    }
    onUpdateSubmit() {
        alert("ok");
        this.onHide('displayResponsive');
    }
    onUpdate(name, rowData) {
        alert(rowData.candidateId);
        alert(rowData.addressId);
        let state = {
            [`${name}`]: true
        };

        this.setState(state);

    }

    onHide(name) {
        this.setState({
            [`${name}`]: false
        });
    }
    actionOnUpdateTemplate(rowData) {
        // alert(rowData.candidateId);
        return (
            <React.Fragment>
                <Button icon="pi pi-pencil" onClick={() => this.onUpdate('displayResponsive', rowData)} />
            </React.Fragment>
        );
    }
    onDelete(rowData) {
        alert(rowData.candidateId + "d");

    }

    actionOnDeleteTemplate(rowData) {
        // alert(rowData.candidateId);
        return (
            <React.Fragment>
                <Button icon="pi pi-trash" onClick={() => this.onDelete(rowData)} />
            </React.Fragment>
        );
    }


    render() {
        return (
            <div>
                <Button icon="pi pi-save" onClick={() => this.onAdd('displayAdd')} />
                <hr></hr>
                <Dialog header="Add Address" visible={this.state.displayAdd} onHide={() => this.onHide('displayAdd')} breakpoints={{ '960px': '75vw' }} style={{ width: '50vw' }} >

                    <div className="p-grid">
                        <div className="p-col-3 p-m-2">
                            <span className="p-float-label">
                                <InputText id="candidate-id" disabled="true" />
                                <label htmlFor="candidate-id">Candidate Id</label>

                            </span>
                        </div>
                        <div className="p-col-3 p-m-2">
                            <span className="p-float-label">
                                <InputText id="city" />
                                <label htmlFor="city">City</label>
                            </span>
                        </div>
                        <div className="p-col-3 p-m-2">
                            <span className="p-float-label">
                                <InputText id="state" />
                                <label htmlFor="state">State</label>
                            </span>
                        </div>

                        <div className="p-col-2 p-m-2">
                            <span className="p-float-label">
                                <Button label="Submit" onClick={() => this.onAddSubmit()} icon="pi pi-save" className="p-button-info p-button-rounded" />
                            </span>
                        </div>

                    </div>
                </Dialog>

                <Dialog header="Update Address" visible={this.state.displayResponsive} onHide={() => this.onHide('displayResponsive')} breakpoints={{ '960px': '75vw' }} style={{ width: '50vw' }} >

                    <div className="p-grid">
                        <div className="p-col-3 p-m-2">
                            <span className="p-float-label">
                                <InputText id="candidate-id" disabled="true" />
                                <label htmlFor="candidate-id">Candidate Id</label>
                                <InputText id="addressId" hidden="true" disabled="true" />
                            </span>
                        </div>
                        <div className="p-col-3 p-m-2">
                            <span className="p-float-label">
                                <InputText id="city" />
                                <label htmlFor="city">City</label>
                            </span>
                        </div>
                        <div className="p-col-3 p-m-2">
                            <span className="p-float-label">
                                <InputText id="state" />
                                <label htmlFor="state">State</label>
                            </span>
                        </div>

                        <div className="p-col-2 p-m-2">
                            <span className="p-float-label">
                                <Button label="Submit" onClick={() => this.onUpdateSubmit()} icon="pi pi-save" className="p-button-info p-button-rounded" />
                            </span>
                        </div>

                    </div>
                </Dialog>

                <Panel header="Address" toggleable>
                    <div className="p-grid">
                        <div className="p-col-10 p-m-2">
                            <DataTable value={this.state.products}>
                                <Column field="candidateId" header="candidateId"></Column>
                                <Column field="addressId" header="addressId"></Column>
                                <Column field="city" header="city"></Column>
                                <Column field="state" header="state"></Column>
                                <Column field="candidateId" body={this.actionOnUpdateTemplate} header="Update"></Column>
                                <Column field="candidateId" field="addressId" body={this.actionOnDeleteTemplate} header="Delete"></Column>

                            </DataTable>
                        </div>

                    </div>
                </Panel>

            </div>
        );
    }
}
export default withRouter(AddressComponent);
