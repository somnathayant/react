import React from 'react';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';

export default class FooterComponent extends React.Component {

    constructor(props) {
        super(props);
       
    }
    
    render() {
        return (
           <div id="footer">
               <p>Product By Intello Group Inc..</p>
           </div>            
            );
    }
}



