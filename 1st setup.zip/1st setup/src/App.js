import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import './App.css';
import CreateEmployee from './createEmployee';
import UpdateEmployee from './updateEmployee'
import SaveUpdatedEmployee from './saveUpdatedEmployee';
class App extends React.Component {
  render() {
    return (
      <Router>
        <div className="container-fluid">

          <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
            <ul class="navbar-nav">
              <li className="nav-item">
                <Link to={'/create'} className="nav-link">Create</Link>
              </li>
              <li className="nav-item">
                <Link to={'/update'} className="nav-link">Update</Link>
              </li>
            </ul>
          </nav>

          <div className="App">
            <Switch>
              <div className="content">
                <Route exact path="/create" component={CreateEmployee} />
                <Route exact path="/update" component={UpdateEmployee} />
                <Route exact path="/displayForUpdate/:id" component={SaveUpdatedEmployee} />
              </div>
            </Switch>
          </div>
        </div>
      </Router>
    );
  }
}
export default App;
