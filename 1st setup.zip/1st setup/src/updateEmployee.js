import React from 'react';
/* import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
 */
export default class UpdateEmployee extends React.Component {
    constructor(props) {
        super(props);
        this.onChangeEmployeeName = this.onChangeEmployeeName.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.state = {
            employee_name: ''
        }
    }
    onChangeEmployeeName(e) {
        this.setState({
            employee_name: e.target.value
        });
    }
    setRedirect = () => {
        this.setState({
          redirect: true
        })
      }
    onSubmit(e) {
        
         
        //this.props.push({pathname: "/displayForUpdate", query: { id: 1 }})
        /* router.push({ pathname: "/displayForUpdate", query: { id: 1 }})
         *//* this.props.history.push('/displayForUpdate', { id: 7 }); */
        e.preventDefault();
    }
    render() {
        return (
            <div style={{ marginTop: 10 }}>
                <h3>Update Employee</h3>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Employee Name:  </label>
                        <input
                            type="text"
                            className="form-control"
                            value={this.state.employee_name}
                            onChange={this.onChangeEmployeeName}
                        />
                    </div>
                    <div className="form-group">
                        <input type="submit" value="Save" className="btn btn-primary" />
                    </div>
                </form>
            </div>
        );
    }
}
