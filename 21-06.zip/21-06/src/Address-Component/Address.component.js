import React from 'react';
import { Redirect } from 'react-router-dom';
import { withRouter } from 'react-router-dom';

 class AddressComponent extends React.Component {

    constructor(props) {
        super(props);
       
    }
    

    onSubmit = () => {
        
        this.props.history.push('/candidate-service');   
     }

    render() {
        return (
            <form onSubmit={this.onSubmit}>
            <h3>Sign In</h3>

            <div className="form-group">
                <label>User ID</label>
                <input type="email" className="form-control" placeholder="Enter email" />
            </div>

            <div className="form-group">
                <label>Password</label>
                <input type="password" className="form-control" placeholder="Enter password" />
            </div>

           
            <button type="submit" className="btn btn-primary btn-block">Submit</button>
            <p className="forgot-password text-right">
                Forgot <a href="#">password?</a>
            </p>
        </form>    
        );
    }
}
export default AddressComponent;
