import React from 'react';
import { Menubar } from 'primereact/menubar';
import {history} from 'history';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import { withRouter } from 'react-router-dom';

 class DashBoardComponent extends React.Component {

  constructor(props) {
    super(props);
    this.onMenubarClick=this.onMenubarClick.bind(this);
     this.items = [
      {
        label: 'Candidate',
        items: [
          {
            label: 'New',
            icon: 'pi pi-fw pi-plus',
            command:()=>{this.onMenubarClick('/candidateEntry')}
          } ,
          {
            label: 'Update',
            icon: 'pi pi-fw pi-plus',
            command:()=>{this.onMenubarClick('/SignUp')}
          } ,
          {
            label: 'Delete',
            icon: 'pi pi-fw pi-trash',
            command:()=>{this.onMenubarClick('/SignUp')}
          } ,
          {
            label: 'Candidate List',
            icon: 'pi pi-fw pi-plus',
            command:()=>{this.onMenubarClick('/candidateList')}
          } 
        ]
      },
    ];
  }
  onMenubarClick = (path) => {
   
    this.props.history.push(path);
}

  render() {
    
    return (
      <div>
        <div className="card">
          <Menubar model={this.items} />
        </div>
      </div>
    );
  }
}

export default withRouter(DashBoardComponent);


