import React from 'react';
import FooterComponent from '../Footer/Footer.component';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
export default class SignUpComponent extends React.Component {

    constructor(props) {
        super(props);

    }

    onSubmit = () => {

        this.props.history.push('/candidate-service');
    }

    render() {
        return (

            <div class="container-fluid" id="signUp-container">
                <div id="signUp-heading">
                    <center><img src="/intello_logo.png" alt="intello Group Inc.." width="150" height="100" /></center>
                </div>
                <center><h2><i>Register yourself with us..</i></h2></center>

                <div id="registration-box-signUp" >
                    <form onSubmit={this.onSubmit}>
                        <div className="p-grid">
                           
                            <div className="p-col-12 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="user-name" />
                                    <label htmlFor="user-name">Username</label>
                                </span>
                            </div>
                            <div className="p-col-12 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="email" />
                                    <label htmlFor="email">Email</label>
                                </span>
                            </div>
                            <div className="p-col-12 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="password" />
                                    <label htmlFor="password">Password</label>
                                </span>
                            </div>
                            <div className="p-col-12 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="confirm-password" />
                                    <label htmlFor="confirm-password">Confirm Password</label>
                                </span>
                            </div>
                        </div>
                        <div className="p-col-12 p-m-2">
                            <Button type="Submit" label="Proceed" className="p-button-raised p-button-rounded" />
                        </div>
                    </form>

                </div>
                <FooterComponent></FooterComponent>
            </div>

        );
    }
}








