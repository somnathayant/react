import React from 'react';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';

export default class UpdateEmployee extends React.Component {
    constructor(props) {
        super(props);
        this.onChangeEmployeeName = this.onChangeEmployeeName.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.state = {
            employee_name: ''
        }
    }
    onChangeEmployeeName(e) {
        this.setState({
            employee_name: e.target.value
        });
    }
    setRedirect = () => {
        this.setState({
          redirect: true
        })
      }
    onSubmit(e) {
       let name=e.target.value;
        console.log("under submit");
       
        e.preventDefault();
    }
    render() {
        return (
            <div style={{ marginTop: 10 }}>
                <h3>Update Employee</h3>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Employee Name:  </label>
                        <input
                            type="text"
                            className="form-control"
                            value={this.state.employee_name}
                            onChange={this.onChangeEmployeeName}
                        />
                    </div>
                    <div className="form-group">
                        <input type="submit" value="Save" className="btn btn-primary" />
                    </div>
                </form>
            </div>
        );
    }
}
