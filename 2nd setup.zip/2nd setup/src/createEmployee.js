import React from 'react';
export default class CreateEmployee extends React.Component {

    constructor(props) {
        super(props);
        this.onChangeEmployeeName = this.onChangeEmployeeName.bind(this);
        this.onChangeEmployeeDesiganation = this.onChangeEmployeeDesiganation.bind(this);
        this.onChangeEmployeeSalary = this.onChangeEmployeeSalary.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            employee_name: '',
            employee_desiganation: '',
            employee_salary: ''
        }
    }
    onChangeEmployeeName(e) {
        this.setState({
            employee_name: e.target.value
        });
    }
    onChangeEmployeeDesiganation(e) {
        this.setState({
            employee_desiganation: e.target.value
        })
    }
    onChangeEmployeeSalary(e) {
        this.setState({
            employee_salary: e.target.value
        })
    }

    onSubmit(e) {
        let isFormStateValid = true;
        let error_salary;
        let error_name;
        /* if (this.state.employee_name === "") {
            isFormStateValid = false;
            error_name = document.getElementById("error_name");
            error_name.innerHTML = "please enter name";
        } else {
            isFormStateValid = true;
            error_name.innerHTML = "";
        } */


        if (this.state.employee_salary === "") {
            isFormStateValid = false;
            error_salary = document.getElementById("error_salary");
            error_salary.innerHTML = "please enter  salary";
          } else {
            isFormStateValid = true;
            error_salary.innerHTML = "";
        }

        if (this.state.employee_salary.match(/^[0-9]+$/)) {
            isFormStateValid = true;
            error_salary.innerHTML = "";
            alert("if");
        } else {
            alert("else");
            isFormStateValid = false;
            error_salary = document.getElementById("error_salary");
            error_salary.innerHTML = "please enter proper salary";
            
        }
        if(!isFormStateValid){
            e.preventDefault();
        }
        
        const obj = {
            employee_name: this.state.employee_name,
            employee_desiganation: this.state.employee_desiganation,
            employee_salary: this.state.employee_salary
        };
        this.setState({
            employee_name: '',
            employee_desiganation: '',
            employee_salary: ''
        });
        console.log(obj.employee_name + " " + obj.employee_desiganation + " " + obj.employee_salary);
    }



    render() {
        return (
            <div style={{ marginTop: 10 }}>
                <h3>Create Employee</h3>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Employee Name:  </label>
                        <input
                            type="text"
                            className="form-control"
                            value={this.state.employee_name}
                            onChange={this.onChangeEmployeeName}
                        />
                        <div id="error_name"></div>
                    </div>
                    <div className="form-group">
                        <label>Desiganation: </label>
                        <input type="text"
                            className="form-control"
                            value={this.state.employee_desiganation}
                            onChange={this.onChangeEmployeeDesiganation}
                        />
                    </div>
                    <div className="form-group">
                        <label>Salary: </label>
                        <input type="text"
                            className="form-control"
                            value={this.state.employee_salary}
                            onChange={this.onChangeEmployeeSalary}
                        />
                    </div>
                    <div id="error_salary"></div>
                    <div className="form-group">
                        <input type="submit" value="Save" className="btn btn-primary" />
                    </div>
                </form>
            </div>
        )
    }
}
