import React from 'react';
export default class SaveUpdatedEmployee extends React.Component {
    constructor(props) {
       
        super(props);
        this.onChangeEmployeeName = this.onChangeEmployeeName.bind(this);
        this.onChangeEmployeeDesiganation = this.onChangeEmployeeDesiganation.bind(this);
        this.onChangeEmployeeSalary = this.onChangeEmployeeSalary.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.state = {
            employee_name: '',
            employee_desiganation: '',
            employee_salary: ''
        }
        
        console.log("ok"+this.props.match.params.name);
    }
    onChangeEmployeeName(e) {
        this.setState({
            employee_name: e.target.value
        });
    }
    onChangeEmployeeDesiganation(e) {
        this.setState({
            employee_desiganation: e.target.value
        })
    }
    onChangeEmployeeSalary(e) {
        this.setState({
            employee_salary: e.target.value
        })
    }

    onSubmit(e) {
        e.preventDefault();
        const obj = {
            employee_name: this.state.employee_name,
            employee_desiganation: this.state.employee_desiganation,
            employee_salary: this.state.employee_salary
        };
        this.setState({
            employee_name: '',
            employee_desiganation: '',
            employee_salary: ''
        });
        console.log(obj.employee_name + " " + obj.employee_desiganation + " " + obj.employee_salary);
    }
    render() {
        return (

            <div style={{ marginTop: 10 }}>
                <h3>Save Updated Employee</h3>
                <div>
                    <h2>{this.props.match.params.id}</h2>
                </div>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Employee Name:  </label>
                        <input
                            type="text"
                            className="form-control"
                            value={this.state.employee_name}
                            onChange={this.onChangeEmployeeName}
                        />
                    </div>
                    <div className="form-group">
                        <label>Desiganation: </label>
                        <input type="text"
                            className="form-control"
                            value={this.state.employee_desiganation}
                            onChange={this.onChangeEmployeeDesiganation}
                        />
                    </div>
                    <div className="form-group">
                        <label>Salary: </label>
                        <input type="text"
                            className="form-control"
                            value={this.state.employee_salary}
                            onChange={this.onChangeEmployeeSalary}
                        />
                    </div>
                    <div className="form-group">
                        <input type="submit" value="Save" className="btn btn-primary" />
                    </div>
                </form>
            </div>
        )
    }
}
