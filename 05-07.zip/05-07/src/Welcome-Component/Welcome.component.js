import React from 'react';
import { Menubar } from 'primereact/menubar';
import {history} from 'history';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import { InputText } from 'primereact/inputtext';

 class WelcomeComponent extends React.Component {

  constructor(props) {
    super(props);
    this.onMenubarClick=this.onMenubarClick.bind(this);
     this.items = [
      {
        label: 'Candidate sign in',
            icon: 'pi pi-sign-in',
            command:()=>{this.onMenubarClick('/SignIn')}
      },
      {
        label: 'Recruiter sign in',
        icon: 'pi pi-sign-in',
        command:()=>{this.onMenubarClick('/SignIn')}
  
      }  
      
    ];
    
  }
  onMenubarClick = (path) => {
   
    this.props.history.push(path);
}

  render() {
    const start =<img src="/intello_logo.png" alt="intello Group Inc.." width="150" height="50" />
        
     return (
      <div>
        <div className="card">
          <Menubar model={this.items}start={start}  />
        </div>
      </div>
    );
  }
}

export default withRouter(WelcomeComponent);


