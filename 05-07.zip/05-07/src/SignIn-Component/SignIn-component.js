import React from 'react';
import { Redirect } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import FooterComponent from '../Footer/Footer.component';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import WelcomeComponent from '../Welcome-Component/Welcome.component';
class SignInComponent extends React.Component {

    constructor(props) {
        super(props);

    }


    onSubmit = () => {

        this.props.history.push('/candidateProfileComponent');
    }

    render() {
        return (
            <div>
                <WelcomeComponent></WelcomeComponent>
                <div class="container-fluid" id="signUp-container">
                    <div id="signUp-heading">
                        <div id="SignUp-img">
                        </div>
                    </div>
                    <div id="registration-box-signIn" >
                        <center><img src="/intello_logo.png" alt="intello Group Inc.." width="150" height="50" /></center>
                        <center><i>Please Sign In..</i></center>
                        <br></br>
                        <form onSubmit={this.onSubmit}>
                            <div className="p-grid">
                                <div className="p-col-12 p-m-2">
                                    <span className="p-float-label">
                                        <InputText id="email" />
                                        <label htmlFor="email">Email</label>
                                    </span>
                                </div>
                                <div className="p-col-12 p-m-2">
                                    <span className="p-float-label">
                                        <InputText id="user-name" />
                                        <label htmlFor="user-name">User Name</label>
                                    </span>
                                </div>
                                <div className="p-col-12 p-m-2">
                                    <div className="p-col-6 p-md-6 p-lg-3">
                                        <Button type="Submit" label="Proceed" className="p-button-raised p-button-rounded" />
                                    </div>
                                    <hr></hr>
                                </div>
                                <div className="p-col-12 p-m-2">
                                    <div className="p-col-12">
                                        <Link to={'/SignUp'} className="nav-link">SignUp|Not Having Account</Link>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                    <FooterComponent></FooterComponent>
                </div>
            </div>
        );
    }
}
export default withRouter(SignInComponent);
