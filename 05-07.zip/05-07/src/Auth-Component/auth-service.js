import axios from 'axios';
const qs = require("qs");
const jwt_decode = require('jwt-decode');
class AuthService {
    constructor() {
    }
    async getToken() {

        const url = "/auth/oauth/token";

        const data = {
            grant_type: "password",
            username: "user",
            password: "password123"
        };

        const auth = {
            username:process.env.React_App_Candidate_Service_Id,
            password:process.env.React_App_Candidate_Service_Secret,
        };

        const options = {
            method: "post",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            data: qs.stringify(data),
            auth: auth,
            url,
        };

        axios(options)
            .then((response) => {
                localStorage.setItem("TOKEN",response.data.access_token);
            })
            .catch((err) => {
                console.log(err);
            });
    }



    async checkTokenExpiry() {
        let token = localStorage.getItem("TOKEN");
        let decodedToken = jwt_decode(token);
        console.log("Decoded Token", decodedToken);
        let currentDate = new Date();

        // JWT exp is in seconds
        if (decodedToken.exp * 1000 < currentDate.getTime()) {
            console.log("Token expired.");
            localStorage.setItem("TOKEN","false");
        } else {
            console.log("Valid token");
           var  result = true;
        }
    }
}
export default AuthService;



















