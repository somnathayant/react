const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
  app.use(
    '/auth/oauth/token',
    createProxyMiddleware({
      target:"http://localhost:9000",
      changeOrigin: true,
    })
  );

  app.use(
    '/resource/candidate/findAll',
    createProxyMiddleware({
      target: 'http://localhost:9000',
      changeOrigin: true,
    })
  );

app.use(
  '/resource/candidate/save',
  createProxyMiddleware({
    target: 'http://localhost:9000',
    changeOrigin: true,
  })
);
};



