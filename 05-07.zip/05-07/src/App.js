import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import './App.css';

import { useHistory } from 'react-router-dom';
import SignUpComponent from './SignUp-Component/SignUp.component';
import CandidateComponent from './CandidateService-Component/candidate-service.component';
import SignInComponent from './SignIn-Component/SignIn-component';
import CandidateListComponent from './CandidateService-Component/CandidateList.component';
import  candidateProfileComponent from './CandidateService-Component/Candidate-Profile.component';
import CandidateEntryComponent from './CandidateService-Component/candidate-entry.component';
import WelcomeComponent from './Welcome-Component/Welcome.component';
import AuthService from './Auth-Component/auth-service';
class App extends React.Component {

  constructor(props) {
    super(props);
    this.authService = new AuthService();

}
//loading method
    componentDidMount() {
        this.authService.getToken();
        //alert(localStorage.getItem("TOKEN"));
    }
  render() {

    return (
      <Router>
          <div className="App">
            <Switch>
              <div className="content">
              <Route exact path="/" component={WelcomeComponent} />
              <Route exact path="/SignIn" component={SignInComponent} />
                <Route exact path="/SignUp" component={SignUpComponent} />
                 <Route exact path="/candidateList" component={CandidateListComponent} />
                <Route exact path="/candidateProfileComponent" component={candidateProfileComponent} />
               
              </div>
            </Switch>
          </div>
      </Router>
    );
  }
}
export default App;
