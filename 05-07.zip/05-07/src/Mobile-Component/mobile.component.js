import React from 'react';
import { Redirect } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import FooterComponent from '../Footer/Footer.component';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import MenubarComponent from '../Menubar-Component/Menubar.component';
import { TabView, TabPanel } from 'primereact/tabview';
import { Panel } from 'primereact/panel';
import { DataTable } from 'primereact/datatable';
import { FileUpload } from 'primereact/fileupload';
import { Column } from 'primereact/column';
import { Dialog } from 'primereact/dialog';
import { Calendar } from 'primereact/calendar';
import MobileService from '../services/mobile-service';
import { RadioButton } from 'primereact/radiobutton';

class MobileComponent extends React.Component {

    constructor(props) {
        super(props);
        this.mobileService = new MobileService();
        this.onAdd = this.onAdd.bind(this);
        this.onHide = this.onHide.bind(this);
        this.onUpdate = this.onUpdate.bind(this);
        this.actionOnUpdateTemplate = this.actionOnUpdateTemplate.bind(this);
        this.onDelete = this.onDelete.bind(this);
        this.actionOnDeleteTemplate = this.actionOnDeleteTemplate.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.CountryCodeChange = this.CountryCodeChange.bind(this);
        this.handleMobileNumberChange = this.handleMobileNumberChange.bind(this);
        this.state = {
            visibleOn: false,
            visibleOff: true,
            displayResponsive: false,
            displayAdd: false,
            mobiles: [],
            candidateId: '',
            id: '',
            countryCode: '',
            mobileNumber: '',

        };
    }

    //handle Change methods
    CountryCodeChange(e) {
        this.setState({ countryCode: e.target.value });
    }
     handleMobileNumberChange(e) {
        this.setState({ mobileNumber: e.target.value });
    }

    //loading method
    componentDidMount() {
        this.mobileService.retrieveMobiles().then(mobiles => {
            this.setState({
                mobiles: mobiles
            });
            this.setState({
                candidateId: mobiles[0].candidateId
            });
        });
    }
    //method to display panel
    onAdd(name) {
        alert("add");
        this.setState({

            countryCode: '',
           
            mobileNumber: '',
        });
        let state = {
            [`${name}`]: true
        };

        this.setState(state);
    }

    //submit method
    onSubmit = (event) => {
        event.preventDefault();

        alert(this.state.currentLocation);
        alert(this.state.prefLocation);




        this.onHide('displayAdd');
        this.onHide('displayResponsive');
    }

    //method to display panel
    onUpdate(name, rowData) {
        alert(rowData.candidateId);
        alert(rowData.id);
        this.setState({
            countryCode: this.state.mobiles[0].countryCode,
           
            mobileNumber: this.state.mobiles[0].mobileNumber,
        });
        let state = {
            [`${name}`]: true
        };

        this.setState(state);
    }
    //hide panel
    onHide(name) {
        this.setState({
            [`${name}`]: false
        });
    }
    //shows pencil icon in datatable for update
    actionOnUpdateTemplate(rowData) {
        // alert(rowData.candidateId);
        return (
            <React.Fragment>
                <Button icon="pi pi-pencil" onClick={() => this.onUpdate('displayResponsive', rowData)} />
            </React.Fragment>
        );
    }
    onDelete(rowData) {
        alert(rowData.candidateId + "d");

    }
    //shows trash icon in datatable for delete
    actionOnDeleteTemplate(rowData) {
        // alert(rowData.candidateId);
        return (
            <React.Fragment>
                <Button icon="pi pi-trash" onClick={() => this.onDelete(rowData)} />
            </React.Fragment>
        );
    }


    render() {
        return (

            <div>

                <Button icon="pi pi-save" onClick={() => this.onAdd('displayAdd')} />
                <hr></hr>
                <Dialog header="Add Mobile" visible={this.state.displayAdd} onHide={() => this.onHide('displayAdd')} breakpoints={{ '960px': '75vw' }} style={{ width: '50vw' }} >
                    <form onSubmit={this.onSubmit}>
                        <div className="p-grid">
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="candidate-id" disabled="true" value={this.state.candidateId} />
                                    <label htmlFor="candidate-id">Candidate Id</label>

                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="countryCode" value={this.state.countryCode} onChange={this.CountryCodeChange} />
                                    <label htmlFor="countryCode">Country Code</label>
                                </span>
                            </div>
                           
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="mobileNumber" value={this.state.mobileNumber} onChange={this.handleMobileNumberChange} />
                                    <label htmlFor="mobileNumber">Mobile Number</label>
                                </span>
                            </div>

                            <div className="p-col-2 p-m-2">
                                <span className="p-float-label">
                                    <Button label="Submit" type="submit" icon="pi pi-save" className="p-button-info p-button-rounded" />
                                </span>
                            </div>

                        </div>
                    </form>
                </Dialog>

                <Dialog header="Update Mobile" visible={this.state.displayResponsive} onHide={() => this.onHide('displayResponsive')} breakpoints={{ '960px': '75vw' }} style={{ width: '50vw' }} >
                    <form onSubmit={this.onSubmit}>
                        <div className="p-grid">
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="candidate-id" disabled="true" value={this.state.candidateId} />
                                    <label htmlFor="candidate-id">Candidate Id</label>
                                    <InputText id="id" hidden="true" value={this.state.id} />
                                
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="countryCode" value={this.state.countryCode} onChange={this.CountryCodeChange} />
                                    <label htmlFor="countryCode">Country Code</label>
                                </span>
                            </div>
                            
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="mobileNumber" value={this.state.mobileNumber} onChange={this.handleMobileNumberChange} />
                                    <label htmlFor="mobileNumber">Mobile Number</label>
                                </span>
                            </div>


                            <div className="p-col-2 p-m-2">
                                <span className="p-float-label">
                                    <Button label="Submit" type="submit" icon="pi pi-save" className="p-button-info p-button-rounded" />
                                </span>
                            </div>

                        </div>
                    </form>
                </Dialog>

                <Panel header="Mobiles" toggleable>
                    <div className="p-grid">
                        <div className="p-col-10 p-m-2">
                            <DataTable value={this.state.mobiles}>
                                <Column field="countryCode" header="Country Code"></Column>
                                <Column field="mobileNumber" header="Mobile Number"></Column>
                                <Column field="candidateId" body={this.actionOnUpdateTemplate} header="Update"></Column>
                                <Column field="candidateId" field="id" body={this.actionOnDeleteTemplate} header="Delete"></Column>

                            </DataTable>
                        </div>

                    </div>
                </Panel>

            </div>
        );
    }
}
export default withRouter(MobileComponent);

