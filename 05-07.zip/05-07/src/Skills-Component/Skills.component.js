import React from 'react';
import { Redirect } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import FooterComponent from '../Footer/Footer.component';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import MenubarComponent from '../Menubar-Component/Menubar.component';
import { TabView, TabPanel } from 'primereact/tabview';
import { Panel } from 'primereact/panel';
import { DataTable } from 'primereact/datatable';
import { FileUpload } from 'primereact/fileupload';
import { Column } from 'primereact/column';
import { Dialog } from 'primereact/dialog';
import { Calendar } from 'primereact/calendar';
import SkillService from '../services/skill-service';
import { RadioButton } from 'primereact/radiobutton';
class SkillComponent extends React.Component {

    constructor(props) {
        super(props);
        this.skillService = new SkillService();
        this.onAdd = this.onAdd.bind(this);
        this.onHide = this.onHide.bind(this);
        this.onUpdate = this.onUpdate.bind(this);
        this.actionOnUpdateTemplate = this.actionOnUpdateTemplate.bind(this);
        this.onDelete = this.onDelete.bind(this);
        this.actionOnDeleteTemplate = this.actionOnDeleteTemplate.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.handleNameChange = this.handleNameChange.bind(this);
        this.handleProficientLevelChange = this.handleProficientLevelChange.bind(this);
        this.state = {
            visibleOn: false,
            visibleOff: true,
            displayResponsive: false,
            displayAdd: false,
            skills: [],
            candidateId: '',
            id: '',
            name: '',
            proficientLevel: '',

        };
    }

    //handle Change methods
    handleNameChange(e) {
        this.setState({ name: e.target.value });
    }
    handleProficientLevelChange(e) {
        this.setState({ proficientLevel: e.target.value });
    }
    //loading method
    componentDidMount() {
        this.skillService.retrieveSkills().then(skills => {
            this.setState({
                skills: skills
            });
        });
    }
    //method to display panel
    onAdd(name) {
        alert("add");
        this.setState({

            name: '',
            proficientLevel: '',
        });
        let state = {
            [`${name}`]: true
        };

        this.setState(state);
    }

    //submit method
    onSubmit = (event) => {
        event.preventDefault();


        this.onHide('displayAdd');
        this.onHide('displayResponsive');
    }

    //method to display panel
    onUpdate(name, rowData) {
        alert(rowData.candidateId);
        alert(rowData.id);
        this.setState({
            candidateId: this.state.skills[0].candidateId,
            id: this.state.skills[0].id,
            name: this.state.skills[0].name,
            proficientLevel: this.state.skills[0].proficientLevel,
        });
        let state = {
            [`${name}`]: true
        };

        this.setState(state);
    }
    //hide panel
    onHide(name) {
        this.setState({
            [`${name}`]: false
        });
    }
    //shows pencil icon in datatable for update
    actionOnUpdateTemplate(rowData) {
        // alert(rowData.candidateId);
        return (
            <React.Fragment>
                <Button icon="pi pi-pencil" onClick={() => this.onUpdate('displayResponsive', rowData)} />
            </React.Fragment>
        );
    }
    onDelete(rowData) {
        alert(rowData.candidateId + "d");

    }
    //shows trash icon in datatable for delete
    actionOnDeleteTemplate(rowData) {
        // alert(rowData.candidateId);
        return (
            <React.Fragment>
                <Button icon="pi pi-trash" onClick={() => this.onDelete(rowData)} />
            </React.Fragment>
        );
    }

    render() {
        return (

            <div>

                <Button icon="pi pi-save" onClick={() => this.onAdd('displayAdd')} />
                <hr></hr>
                <Dialog header="Add Skill" visible={this.state.displayAdd} onHide={() => this.onHide('displayAdd')} breakpoints={{ '960px': '75vw' }} style={{ width: '50vw' }} >
                    <form onSubmit={this.onSubmit}>
                        <div className="p-grid">
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="candidate-id" disabled="true" value={this.state.candidateId} />
                                    <label htmlFor="candidate-id">Candidate Id</label>

                                </span>
                            </div>

                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="name" value={this.state.name} onChange={this.handleNameChange} />
                                    <label htmlFor="name">Name</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="proficientLevel" value={this.state.proficientLevel} onChange={this.handleProficientLevelChange} />
                                    <label htmlFor="proficientLevel">Proficient Level</label>
                                </span>
                            </div>
                            <div className="p-col-2 p-m-2">
                                <span className="p-float-label">
                                    <Button label="Submit" type="submit" icon="pi pi-save" className="p-button-info p-button-rounded" />
                                </span>
                            </div>

                        </div>
                    </form>
                </Dialog>

                <Dialog header="Update Skill" visible={this.state.displayResponsive} onHide={() => this.onHide('displayResponsive')} breakpoints={{ '960px': '75vw' }} style={{ width: '50vw' }} >
                    <form onSubmit={this.onSubmit}>
                        <div className="p-grid">
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="candidate-id" disabled="true" value={this.state.candidateId} />
                                    <label htmlFor="candidate-id">Candidate Id</label>
                                    <InputText id="id" hidden="true" value={this.state.id} />
                               
                                </span>
                            </div>

                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="name" value={this.state.name} onChange={this.handleNameChange} />
                                    <label htmlFor="name">Name</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="proficientLevel" value={this.state.proficientLevel} onChange={this.handleProficientLevelChange} />
                                    <label htmlFor="proficientLevel">Proficient Level</label>
                                </span>
                            </div>

                            <div className="p-col-2 p-m-2">
                                <span className="p-float-label">
                                    <Button label="Submit" type="submit" icon="pi pi-save" className="p-button-info p-button-rounded" />
                                </span>
                            </div>

                        </div>
                    </form>
                </Dialog>

                <Panel header="Skills" toggleable>
                    <div className="p-grid">
                        <div className="p-col-10 p-m-2">
                            <DataTable value={this.state.skills}>
                                <Column field="name" header="Name"></Column>
                                <Column field="proficientLevel" header="Proficient Level"></Column>
                                <Column field="candidateId" body={this.actionOnUpdateTemplate} header="Update"></Column>
                                <Column field="candidateId" field="locId" body={this.actionOnDeleteTemplate} header="Delete"></Column>

                            </DataTable>
                        </div>


                    </div>
                </Panel>

            </div>
        );
    }
} export default withRouter(SkillComponent);
