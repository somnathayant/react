import React from 'react';
import { Redirect } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import FooterComponent from '../Footer/Footer.component';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import MenubarComponent from '../Menubar-Component/Menubar.component';
import { TabView, TabPanel } from 'primereact/tabview';
import { Panel } from 'primereact/panel';
import { DataTable } from 'primereact/datatable';
import { FileUpload } from 'primereact/fileupload';
import { Column } from 'primereact/column';
import { Dialog } from 'primereact/dialog';
import { Calendar } from 'primereact/calendar';
import SalaryService from '../services/salary-service';
import { RadioButton } from 'primereact/radiobutton';

class SalaryComponent extends React.Component {

    constructor(props) {
        super(props);
        this.salaryService = new SalaryService();
        this.onAdd = this.onAdd.bind(this);
        this.onHide = this.onHide.bind(this);
        this.onUpdate = this.onUpdate.bind(this);
        this.actionOnUpdateTemplate = this.actionOnUpdateTemplate.bind(this);
        this.onDelete = this.onDelete.bind(this);
        this.actionOnDeleteTemplate = this.actionOnDeleteTemplate.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.isHourlyChange = this.isHourlyChange.bind(this);
        this.handleisYearlyChange = this.handleisYearlyChange.bind(this);
        this.state = {
            visibleOn: false,
            visibleOff: true,
            displayResponsive: false,
            displayAdd: false,
            salaryTypes: [],
            candidateId: '',
            id: '',
            isHourly: '',
            isYearly: '',

        };
    }

    //handle Change methods
    isHourlyChange(e) {
        this.setState({
            isHourly: e.target.value,
        });


    }
    handleisYearlyChange(e) {
        this.setState({
            isYearly: e.target.value,
        });

    }

    //loading method
    componentDidMount() {
        this.salaryService.retrieveSalaryTypes().then(salaryTypes => {
            this.setState({
                salaryTypes: salaryTypes
            });
            this.setState({
                candidateId: salaryTypes[0].candidateId
            });
        });
    }
    //method to display panel
    onAdd(name) {
        alert("add");
        this.setState({
            isHourly: '',
            isYearly: '',

        });
        let state = {
            [`${name}`]: true
        };

        this.setState(state);
    }

    //submit method
    onSubmit = (event) => {
        event.preventDefault();


        alert(this.state.isHourly + "h");
        alert(this.state.isYearly + "y");

        this.onHide('displayAdd');
        this.onHide('displayResponsive');
    }

    //method to display panel
    onUpdate(name, rowData) {
        alert(rowData.candidateId);
        alert(rowData.id);
        this.setState({

            isHourly: this.state.salaryTypes[0].isHourly,

            isYearly: this.state.salaryTypes[0].isYearly,
        });
        let state = {
            [`${name}`]: true
        };

        this.setState(state);
    }
    //hide panel
    onHide(name) {
        this.setState({
            [`${name}`]: false
        });
    }
    //shows pencil icon in datatable for update
    actionOnUpdateTemplate(rowData) {
        // alert(rowData.candidateId);
        return (
            <React.Fragment>
                <Button icon="pi pi-pencil" onClick={() => this.onUpdate('displayResponsive', rowData)} />
            </React.Fragment>
        );
    }
    onDelete(rowData) {
        alert(rowData.candidateId + "d");

    }
    //shows trash icon in datatable for delete
    actionOnDeleteTemplate(rowData) {
        // alert(rowData.candidateId);
        return (
            <React.Fragment>
                <Button icon="pi pi-trash" onClick={() => this.onDelete(rowData)} />
            </React.Fragment>
        );
    }


    render() {
        return (

            <div>

                <Button icon="pi pi-save" onClick={() => this.onAdd('displayAdd')} />
                <hr></hr>
                <Dialog header="Add Mobile" visible={this.state.displayAdd} onHide={() => this.onHide('displayAdd')} breakpoints={{ '960px': '75vw' }} style={{ width: '50vw' }} >
                    <form onSubmit={this.onSubmit}>
                        <div className="p-grid">
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="candidate-id" disabled="true" value={this.state.candidateId} />
                                    <label htmlFor="candidate-id">Candidate Id</label>

                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">

                                <div className="p-field-radiobutton">
                                    <RadioButton inputId="isHourly" name="salary" value={this.state.isHourly} onChange={this.isHourlyChange} checked={'true' === this.state.isHourly} />
                                    <label htmlFor="isHourly">Hourly Salary</label>
                                </div>

                            </div>
                            <div className="p-col-4 p-m-2">
                                <div className="p-field-radiobutton">
                                    <RadioButton inputId="isYearly" name="salary" value={this.state.isYearly} onChange={this.handleisYearlyChange} checked={'true' === this.state.isYearly} />
                                    <label htmlFor="isYearly">Yearly Salary</label>
                                </div>

                            </div>
                            <div className="p-col-2 p-m-2">
                                <span className="p-float-label">
                                    <Button label="Submit" type="submit" icon="pi pi-save" className="p-button-info p-button-rounded" />
                                </span>
                            </div>

                        </div>
                    </form>
                </Dialog>

                <Dialog header="Update Salary" visible={this.state.displayResponsive} onHide={() => this.onHide('displayResponsive')} breakpoints={{ '960px': '75vw' }} style={{ width: '50vw' }} >
                    <form onSubmit={this.onSubmit}>
                        <div className="p-grid">
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="candidate-id" disabled="true" value={this.state.candidateId} />
                                    <label htmlFor="candidate-id">Candidate Id</label>

                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">

                                <div className="p-field-radiobutton">
                                    <RadioButton inputId="isHourly" name="salary" value={this.state.isHourly} onChange={this.isHourlyChange} checked={'true' === this.state.isHourly} />
                                    <label htmlFor="isHourly">Hourly Salary</label>
                                </div>

                            </div>
                            <div className="p-col-4 p-m-2">
                                <div className="p-field-radiobutton">
                                    <RadioButton inputId="isYearly" name="salary" value={this.state.isYearly} onChange={this.handleisYearlyChange} checked={'true' === this.state.isYearly} />
                                    <label htmlFor="isYearly">Yearly Salary</label>
                                </div>

                            </div>

                            <div className="p-col-2 p-m-2">
                                <span className="p-float-label">
                                    <Button label="Submit" type="submit" icon="pi pi-save" className="p-button-info p-button-rounded" />
                                </span>
                            </div>

                        </div>
                    </form>
                </Dialog>

                <Panel header="Salary Types" toggleable>
                    <div className="p-grid">
                        <div className="p-col-10 p-m-2">
                            <DataTable value={this.state.salaryTypes}>
                                <Column field="isHourly" header="Hourly"></Column>
                                <Column field="isYearly" header="Yearly"></Column>
                                <Column field="candidateId" body={this.actionOnUpdateTemplate} header="Update"></Column>
                                <Column field="candidateId" field="id" body={this.actionOnDeleteTemplate} header="Delete"></Column>

                            </DataTable>
                        </div>

                    </div>
                </Panel>

            </div>
        );
    }
}
export default withRouter(SalaryComponent);
