import React from 'react';
import { Menubar } from 'primereact/menubar';
import {history} from 'history';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import { InputText } from 'primereact/inputtext';

 class MenubarComponent extends React.Component {

  constructor(props) {
    super(props);
    this.onMenubarClick=this.onMenubarClick.bind(this);
     this.items = [
      {
        label: 'Candidate List',
            icon: 'pi pi-users',
            command:()=>{this.onMenubarClick('/candidateList')}
      },
      {
        label: 'Profile',
        icon: 'pi pi-user',
        command:()=>{this.onMenubarClick('/candidateProfileComponent')}
  
      }  
      
    ];
    this.endOption=[{
      label: 'Sign out',
      icon: 'pi pi-sign-out',
      command:()=>{this.onMenubarClick('/')}

    }]
  }
  onMenubarClick = (path) => {
   
    this.props.history.push(path);
}

  render() {
    const start =<img src="/intello_logo.png" alt="intello Group Inc.." width="150" height="50" />
    const end =<Link to='/'>sign out</Link>

       
     return (
      <div>
        <div className="card">
          <Menubar model={this.items}start={start} end={end} />
        </div>
      </div>
    );
  }
}

export default withRouter(MenubarComponent);


