import React from 'react';
import FooterComponent from '../Footer/Footer.component';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import { TabView, TabPanel } from 'primereact/tabview';
import { Panel } from 'primereact/panel';
import { Calendar } from 'primereact/calendar';
import { Password } from 'primereact/password';
import { Dropdown } from 'primereact/dropdown';
import WelcomeComponent from '../Welcome-Component/Welcome.component';
import axios from 'axios';

import CandidateService from '../services/candidate-service';

const qs = require("qs");
export default class SignUpComponent extends React.Component {

    constructor(props) {
        super(props);
        this.candidateService = new CandidateService();
        this.onSubmit = this.onSubmit.bind(this);
        this.getCandidates=this.getCandidates.bind(this);
        this.onChangeAliasName = this.onChangeAliasName.bind(this);
        this.onChangeFirstName = this.onChangeFirstName.bind(this);
        this.onChangeMiddleName = this.onChangeMiddleName.bind(this);
        this.onChangeLastName = this.onChangeLastName.bind(this);
        this.onChangeProfileTitle = this.onChangeProfileTitle.bind(this);
        this.onChangeInterViewMode = this.onChangeInterViewMode.bind(this);
        this.onChangeInterviewStatuses = this.onChangeInterviewStatuses.bind(this);
        this.onChangePassword = this.onChangePassword.bind(this);
        this.onChangeWorkExperience = this.onChangeWorkExperience.bind(this);
        this.onChangeReleventExperience = this.onChangeReleventExperience.bind(this);
        this.onChangeComment = this.onChangeComment.bind(this);
        this.onChangeEmail = this.onChangeEmail.bind(this);
        this.onChangeAlternateEmail = this.onChangeAlternateEmail.bind(this);
        this.onChangeCoverLetter = this.onChangeCoverLetter.bind(this);
        this.onChangeSummary = this.onChangeSummary.bind(this);
        this.onChangeBirthDate = this.onChangeBirthDate.bind(this);
        this.hiringTypesChange = this.hiringTypesChange.bind(this);
        this.state = {
            candidate:'',
            interViewMode: null,
            interviewStatus: null,
            hiringType: null,
            aliasName: '',
            firstName: '',
            middleName: '',
            lastName: '',
            profileTitle: '',
            interViewMode: '',
            interviewStatuses: '',
            birthDate: '',
            password: '',
            workExperience: '',
            releventExperience: '',
            comment: '',
            hiringType: '',
            email: '',
            alternateEmail: '',
            coverLetter: '',
            summary: ''
        };
        this.interViewModes = [
            { "name": 'Skype' },
            { "name": 'Zoom' },
            { "name": 'Webex' },
            { "name": 'F2F' },
            { "name": 'N/A' }
        ];
        this.interviewStatuses = [
            { "name": "Scheduled" },
            { "name": "PO Received" },
            { "name": "Project Started" },
            { "name": "Rejected" },
            { "name": "Pending" },
            { "name": 'N/A' }
        ];
        this.hiringTypes = [
            { "name": "W2" },
            { "name": "C2C" },
            { "name": "C2H" },
        ]


    }
    //method registering
    onChangeAliasName(e) {
        this.setState({
            aliasName: e.target.value
        });
    }

    onChangeFirstName(e) {
        this.setState({
            firstName: e.target.value
        });
    }
    onChangeMiddleName(e) {
        this.setState({
            middleName: e.target.value
        });
    }
    onChangeLastName(e) {
        this.setState({
            lastName: e.target.value
        });
    }
    onChangeProfileTitle(e) {
        this.setState({
            profileTitle: e.target.value
        });
    }
    onChangeInterViewMode(e) {
        this.setState({
            interViewMode: e.target.value
        });
    }
    onChangeInterviewStatuses(e) {
        this.setState({
            interviewStatuses: e.target.value
        });
    }
    onChangePassword(e) {
        this.setState({
            password: e.target.value
        });
    }
    onChangeWorkExperience(e) {
        this.setState({
            workExperience: e.target.value
        });
    }
    onChangeReleventExperience(e) {
        this.setState({
            releventExperience: e.target.value
        });
    }
    onChangeComment(e) {
        this.setState({
            comment: e.target.value
        });
    }
    onChangeEmail(e) {
        this.setState({
            email: e.target.value
        });
    }
    onChangeAlternateEmail(e) {
        this.setState({
            alternateEmail: e.target.value
        });
    }
    onChangeCoverLetter(e) {
        this.setState({
            coverLetter: e.target.value
        });
    }
    onChangeSummary(e) {
        this.setState({
            summary: e.target.value
        });
    }
    onChangeBirthDate(e) {
        this.setState({
            birthDate: new Date(e.target.value)
        });
    }
    hiringTypesChange(e) {
        this.setState({
            hiringType: e.target.value
        });
    }
    onSubmit(e) {
        e.preventDefault();

    }
    getCandidates=async()=>{
        this.state.candidate=await this.candidateService.getCandidates();
      alert(this.state.candidate.candidateId+"view");
     }
    //Loading option
    componentDidMount() {
        try{
        this.getCandidates();
        }catch(err){

        }
    }
    hiringTypesChange(e) {
        this.setState({ hiringType: e.value });
    }
    interViewModeChange(e) {
        this.setState({ interViewMode: e.value });
    }

    interviewStatusesChange(e) {
        this.setState({ interviewStatus: e.value });

    }

    onSubmit = (e) => {
        e.preventDefault();
        //const newDate=new Date(this.state.birthDate);

        var todayTime = new Date(this.state.birthDate);
        var month = todayTime.getMonth() + 1;
        var day = todayTime.getDate();
        var year = todayTime.getFullYear();
        const candidate = {
            aliasName: this.state.aliasName,
            firstName: this.state.firstName,
            middleName: this.state.middleName,
            lastName: this.state.lastName,
            profileTitle: this.state.profileTitle,
            interViewMode: JSON.stringify(this.state.interViewMode.name),
            interviewStatuses: JSON.stringify(this.state.interviewStatuses.name),
            birthDate: month + "/" + day + "/" + year,
            password: this.state.password,
            workExperience: this.state.workExperience,
            releventExperience: this.state.releventExperience,
            comment: this.state.comment,
            hiringType: JSON.stringify(this.state.hiringType.name),
            email: this.state.email,
            alternateEmail: this.state.alternateEmail,
            coverLetter: this.state.coverLetter,
            summary: this.state.summary
        }
        
           //this.candidateService.saveCandidate(candidate);
            this.props.history.push({
                pathname:'/CandidateProfileComponent',
                state: { candidateIdValue:this.state.candidate.candidateId}
            });
    }

    render() {
        return (
            <div>
                <WelcomeComponent></WelcomeComponent>
                <div class="container-fluid" id="signUp-container">
                    <div id="registration-box-signUp" >
                        <div id="signUp-heading">
                            <center> <img src="/intello_logo.png" alt="intello Group Inc.." width="150" height="50" /></center>
                        </div>
                        <form onSubmit={this.onSubmit}>
                            <Panel header="Please Register">

                                <TabView >
                                    <TabPanel header="Personal Data">
                                        <div className="p-grid">
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="aliasName" value={this.state.aliasName}
                                                        onChange={this.onChangeAliasName} />
                                                    <label htmlFor="aliasName">Alias Name</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="firstName" value={this.state.firstName}
                                                        onChange={this.onChangeFirstName} />
                                                    <label htmlFor="firstName">First Name</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">

                                                    <InputText id="middleName" value={this.state.middleName}
                                                        onChange={this.onChangeMiddleName} />
                                                    <label htmlFor="middleName">Middle Name</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">

                                                    <InputText id="lastName" value={this.state.lastName}
                                                        onChange={this.onChangeLastName} />
                                                    <label htmlFor="lastName">Last Name</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <Calendar id="birth-date" dateFormat="mm/dd/yy" value={this.state.birthDate}
                                                        onChange={this.onChangeBirthDate} placeholder="Birth Date"></Calendar>
                                                    <label htmlFor="birth-date">Birth Date</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <Password id="password" placeholder="Password" value={this.state.password}
                                                    onChange={this.onChangePassword} />
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <Password id="confirmPassword" placeholder=" Confirm Password" />
                                            </div>
                                        </div>

                                    </TabPanel>
                                    <TabPanel header="Professional Data">
                                        <div className="p-grid">
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="profileTitle" value={this.state.profileTitle}
                                                        onChange={this.onChangeProfileTitle} />
                                                    <label htmlFor="profileTitle">profileTitle</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                            <span className="p-float-label">
                                                <Dropdown id="interViewMode"value={this.state.interViewMode} options={this.interViewModes} onChange={this.onChangeInterViewMode} optionLabel="name" placeholder="Interview Mode" />
                                                <label htmlFor="interViewMode">Interview Mode</label>
                                            </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                <Dropdown id="interviewStatus"value={this.state.interviewStatuses} options={this.interviewStatuses} onChange={this.onChangeInterviewStatuses} optionLabel="name" placeholder="Interview Status" />
                                                <label htmlFor="interviewStatus">Interview Status</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="workExperience" value={this.state.workExperience}
                                                        onChange={this.onChangeWorkExperience} />
                                                    <label htmlFor="workExperience">workExperience</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="releventExperience" value={this.state.ReleventExperience}
                                                        onChange={this.onChangeReleventExperience} />
                                                    <label htmlFor="releventExperience">releventExperience</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="comment" value={this.state.comment}
                                                        onChange={this.onChangeComment} />
                                                    <label htmlFor="comment">comment</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                
                                                    <Dropdown id="hiringType"value={this.state.hiringType} options={this.hiringTypes} onChange={this.hiringTypesChange} optionLabel="name" placeholder="Hiring Type" />
                                                    <label htmlFor="hiringType">Hiring Type</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="email" value={this.state.email}
                                                        onChange={this.onChangeEmail} />
                                                    <label htmlFor="email">email</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="alternateEmail" value={this.state.alternateEmail}
                                                        onChange={this.onChangeAlternateEmail} />
                                                    <label htmlFor="alternateEmail">email</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="coverLetter" value={this.state.coverLetter}
                                                        onChange={this.onChangeCoverLetter} />
                                                    <label htmlFor="coverLetter">coverLetter</label>
                                                </span>
                                            </div>
                                            <div className="p-col-5 p-m-2">
                                                <span className="p-float-label">
                                                    <InputText id="summary" value={this.state.summary}
                                                        onChange={this.onChangeSummary} />
                                                    <label htmlFor="summary">summary</label>
                                                </span>
                                            </div>
                                        </div>

                                    </TabPanel>

                                </TabView>
                                <Button label="Submit" className="p-button-info p-button-rounded" />

                            </Panel>
                        </form>
                    </div>

                    <FooterComponent></FooterComponent>
                </div>
            </div>

        );
    }
}








