import React from 'react';
import { Redirect } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import FooterComponent from '../Footer/Footer.component';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import MenubarComponent from '../Menubar-Component/Menubar.component';
import { TabView, TabPanel } from 'primereact/tabview';
import { Panel } from 'primereact/panel';
import { DataTable } from 'primereact/datatable';
import { FileUpload } from 'primereact/fileupload';
import { Column } from 'primereact/column';
import { Dialog } from 'primereact/dialog';
import { Calendar } from 'primereact/calendar';
import EducationService from '../services/education-service';
import ExperienceService from '../services/experience-service';
import { RadioButton } from 'primereact/radiobutton';
class ExperienceComponent extends React.Component {

    constructor(props) {
        super(props);
        this.experienceService = new ExperienceService();
        this.onAdd = this.onAdd.bind(this);
        this.onHide = this.onHide.bind(this);
        this.onUpdate = this.onUpdate.bind(this);
        this.actionOnUpdateTemplate = this.actionOnUpdateTemplate.bind(this);
        this.onDelete = this.onDelete.bind(this);
        this.actionOnDeleteTemplate = this.actionOnDeleteTemplate.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.handleTitleChange = this.handleTitleChange.bind(this);
        this.handleSummaryChange = this.handleSummaryChange.bind(this);
        this.handleCompanyChange = this.handleCompanyChange.bind(this);
        this.handleStartDateChange = this.handleStartDateChange.bind(this);
        this.handleEndDateChange = this.handleEndDateChange.bind(this);
        this.handleIndustryChange = this.handleIndustryChange.bind(this);
        this.handleisCurrentChange = this.handleisCurrentChange.bind(this);

        this.state = {
            visibleOn: false,
            visibleOff: true,
            displayResponsive: false,
            displayAdd: false,
            experiences: [],
            candidateId: '',
            id: '',
            title: '',
            summary: '',
            startDate: '',
            endDate: '',
            company: '',
            industry: '',
            isCurrent: ''
        };
    }

    //handle Change methods
    handleTitleChange(e) {
        this.setState({ title: e.target.value });
    }
    handleSummaryChange(e) {
        this.setState({ summary: e.target.value });
    } handleCompanyChange(e) {
        this.setState({ company: e.target.value });
    } handleStartDateChange(e) {
        this.setState({ startDate: e.target.value });
    } handleEndDateChange(e) {
        this.setState({ endDate: e.target.value });
    }
    handleIndustryChange(e) {
        this.setState({ industry: e.target.value });
    } handleisCurrentChange(e) {
        this.setState({ isCurrent: e.target.value });
    }

    //loading method
    componentDidMount() {

        this.experienceService.retrieveExperiences().then(exp => {

            this.setState({
                experiences: exp
            });

        });


    }
    //method to display panel
    onAdd(name) {
        alert("add");
        this.setState({

            title: '',
            summary: '',
            startDate: '',
            endDate: '',
            company: '',
            industry: '',
            isCurrent: null,
        });
        let state = {
            [`${name}`]: true
        };

        this.setState(state);
    }

    //submit method
    onSubmit = (event) => {
        event.preventDefault();


        alert(this.state.isCurrent);
        alert(new Date(this.state.startDate).toLocaleDateString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' })); // 08/19/2020 (month and day with two digits)

        this.onHide('displayAdd');
        this.onHide('displayResponsive');
    }

    //method to display panel
    onUpdate(name, rowData) {
        alert(rowData.candidateId);
        alert(rowData.id);
        this.setState({
            candidateId: this.state.experiences[0].candidateId,
            id: this.state.experiences[0].id,
            title: this.state.experiences[0].title,
            summary: this.state.experiences[0].summary,
            startDate: new Date(this.state.experiences[0].startDate),
            endDate: new Date(this.state.experiences[0].endDate),
            company: this.state.experiences[0].company,
            industry: this.state.experiences[0].industry,
            isCurrent: this.state.experiences[0].isCurrent
        });
        let state = {
            [`${name}`]: true
        };

        this.setState(state);
    }
    //hide panel
    onHide(name) {
        this.setState({
            [`${name}`]: false
        });
    }
    //shows pencil icon in datatable for update
    actionOnUpdateTemplate(rowData) {
        // alert(rowData.candidateId);
        return (
            <React.Fragment>
                <Button icon="pi pi-pencil" onClick={() => this.onUpdate('displayResponsive', rowData)} />
            </React.Fragment>
        );
    }
    onDelete(rowData) {
        alert(rowData.candidateId + "d");

    }
    //shows trash icon in datatable for delete
    actionOnDeleteTemplate(rowData) {
        // alert(rowData.candidateId);
        return (
            <React.Fragment>
                <Button icon="pi pi-trash" onClick={() => this.onDelete(rowData)} />
            </React.Fragment>
        );
    }

    render() {
        return (
            <div>

                <Button icon="pi pi-save" onClick={() => this.onAdd('displayAdd')} />
                <hr></hr>
                <Dialog header="Add Experience" visible={this.state.displayAdd} onHide={() => this.onHide('displayAdd')} breakpoints={{ '960px': '75vw' }} style={{ width: '50vw' }} >
                    <form onSubmit={this.onSubmit}>
                        <div className="p-grid">
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="candidate-id" disabled="true" value={this.state.candidateId} />
                                    <label htmlFor="candidate-id">Candidate Id</label>

                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="title" value={this.state.title} onChange={this.handleTitleChange} />
                                    <label htmlFor="title">Title</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="summary" value={this.state.summary} onChange={this.handleSummaryChange} />
                                    <label htmlFor="summary">Summary</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="company" value={this.state.company} onChange={this.handleCompanyChange} />
                                    <label htmlFor="company">Company</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="industry" value={this.state.industry} onChange={this.handleIndustryChange} />
                                    <label htmlFor="industry">Industry</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <div className="p-field-radiobutton">
                                    <RadioButton inputId="isCurrent" name="isCurrent" value="true" name="isCurrent" onChange={this.handleisCurrentChange} checked={'true' === this.state.isCurrent} />
                                    <label htmlFor="isCurrent">Current Experience</label>
                                </div>
                                <div className="p-field-radiobutton">
                                    <RadioButton inputId="isPrevious" name="isCurrent" value="false" name="isCurrent" onChange={this.handleisCurrentChange} checked={'false' === this.state.isCurrent} />
                                    <label htmlFor="isPrevious">Previous Experience</label>
                                </div>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <Calendar id="startDate" dateFormat="mm/dd/yy" placeholder="Start Date(mm/dd/yy)" value={this.state.startDate} onChange={this.handleStartDateChange}></Calendar>
                                    <label htmlFor="startDate">Start Date</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <Calendar id="endDate" dateFormat="mm/dd/yy" placeholder="End Date(mm/dd/yy)" value={this.state.endDate} onChange={this.handleEndDateChange}></Calendar>
                                    <label htmlFor="endDate">End Date</label>
                                </span>
                            </div>
                            <div className="p-col-2 p-m-2">
                                <span className="p-float-label">
                                    <Button label="Submit" type="submit" icon="pi pi-save" className="p-button-info p-button-rounded" />
                                </span>
                            </div>

                        </div>
                    </form>
                </Dialog>

                <Dialog header="Update Experience" visible={this.state.displayResponsive} onHide={() => this.onHide('displayResponsive')} breakpoints={{ '960px': '75vw' }} style={{ width: '50vw' }} >
                    <form onSubmit={this.onSubmit}>
                        <div className="p-grid">
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="candidate-id" disabled="true" value={this.state.candidateId} />
                                    <label htmlFor="candidate-id">Candidate Id</label>
                                    <InputText id="id" hidden="true" value={this.state.id} />
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="title" value={this.state.title} onChange={this.handleTitleChange} />
                                    <label htmlFor="title">Title</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="summary" value={this.state.summary} onChange={this.handleSummaryChange} />
                                    <label htmlFor="summary">Summary</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="company" value={this.state.company} onChange={this.handleCompanyChange} />
                                    <label htmlFor="company">Company</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="industry" value={this.state.industry} onChange={this.handleIndustryChange} />
                                    <label htmlFor="industry">Industry</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <div className="p-field-radiobutton">
                                    <RadioButton inputId="isCurrent" name="isCurrent" value="true" name="isCurrent" onChange={this.handleisCurrentChange} checked={'true' === this.state.isCurrent} />
                                    <label htmlFor="isCurrent">Current Experience</label>
                                </div>
                                <div className="p-field-radiobutton">
                                    <RadioButton inputId="isPrevious" name="isCurrent" value="false" name="isCurrent" onChange={this.handleisCurrentChange} checked={'false' === this.state.isCurrent} />
                                    <label htmlFor="isPrevious">Previous Experience</label>
                                </div>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <Calendar id="startDate" dateFormat="mm/dd/yy" placeholder="Start Date(mm/dd/yy)" value={this.state.startDate} onChange={this.handleStartDateChange}></Calendar>
                                    <label htmlFor="startDate">Start Date</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <Calendar id="endDate" dateFormat="mm/dd/yy" placeholder="End Date(mm/dd/yy)" value={this.state.endDate} onChange={this.handleEndDateChange}></Calendar>
                                    <label htmlFor="endDate">End Date</label>
                                </span>
                            </div>
                            <div className="p-col-2 p-m-2">
                                <span className="p-float-label">
                                    <Button label="Submit" type="submit" icon="pi pi-save" className="p-button-info p-button-rounded" />
                                </span>
                            </div>

                        </div>
                    </form>
                </Dialog>

                <Panel header="Experiences" toggleable>
                    <div className="p-grid">
                        <div className="p-col-10 p-m-2">
                            <DataTable value={this.state.experiences}>
                                <Column field="title" header="Title"></Column>
                                <Column field="company" header="Company"></Column>
                                <Column field="startDate" header="Start Date"></Column>
                                <Column field="endDate" header="End Date"></Column>
                                <Column field="industry" header="Industry"></Column>

                                <Column field="candidateId" body={this.actionOnUpdateTemplate} header="Update"></Column>
                                <Column field="candidateId" field="id" body={this.actionOnDeleteTemplate} header="Delete"></Column>

                            </DataTable>
                        </div>

                    </div>
                </Panel>

            </div >
        );
    }
}

export default withRouter(ExperienceComponent);
