import React from 'react';
import { Redirect } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import FooterComponent from '../Footer/Footer.component';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import { Panel } from 'primereact/panel';
import MenubarComponent from '../Menubar-Component/Menubar.component';
import { TabView, TabPanel } from 'primereact/tabview';
import CandidateEntryComponent from './candidate-entry.component';
import AddressComponent from '../Address-Component/Address.component';
import EducationComponent from '../Education-Component/education.component';
import ExperienceComponent from '../Experience-Component/experience.component';
import JoblocationComponent from '../JobLocation-Component/joblocation.component';
import MobileComponent from '../Mobile-Component/mobile.component';
import PhoneComponent from '../Phone-Component/phone.component';
import SalaryComponent from '../salary-component/salary.component';
import SkillComponent from '../Skills-Component/Skills.component';
import SocialProfileComponent from '../SocialProfile_Component/social-profile.component';
import DocumentComponent from '../Document-Component/document.component';
import { FileUpload } from 'primereact/fileupload';
class candidateProfileComponent extends React.Component {

    constructor(props) {
        super(props);

    }
    componentDidMount() {
        alert(this.props.location.state.candidateIdValue);
    }

    onSubmit = () => {

        this.props.history.push('/CandidateProfileComponent');
    }

    render() {
        return (
            <div>
                <MenubarComponent></MenubarComponent>

                <div class="container-fluid" >

                    <Panel header="Candidate Intro" toggleable>
                        <div className="p-grid">

                            <div className="p-col-1">
                                <img src="/somnath.jpg" alt="Image Please" width="100" height="70" />
                                <hr></hr>
                                <FileUpload name="demo" url="./upload" mode="basic"  />
                            </div>
                            <div className="p-col-11">
                                <Panel header="Official Data" toggleable>
                                    <TabView activeIndex={0}>
                                        <TabPanel header="Candidate data">
                                            <CandidateEntryComponent></CandidateEntryComponent>
                                        </TabPanel>
                                        <TabPanel header="Address Info">
                                            <AddressComponent></AddressComponent>
                                        </TabPanel>
                                        <TabPanel header="Education">
                                            <EducationComponent></EducationComponent>
                                        </TabPanel>
                                        <TabPanel header="Experience">
                                            <ExperienceComponent></ExperienceComponent>
                                        </TabPanel>
                                        <TabPanel header="Job Location">
                                            <JoblocationComponent></JoblocationComponent>
                                        </TabPanel>
                                        <TabPanel header="Mobile">
                                            <MobileComponent></MobileComponent>
                                        </TabPanel>
                                        <TabPanel header="Phone">
                                            <PhoneComponent></PhoneComponent>
                                        </TabPanel>
                                        <TabPanel header="Salary">
                                            <SalaryComponent></SalaryComponent>
                                        </TabPanel>
                                        <TabPanel header="Skill">
                                            <SkillComponent></SkillComponent>
                                        </TabPanel>
                                        <TabPanel header="Social Profile">
                                            <SocialProfileComponent></SocialProfileComponent>
                                        </TabPanel>
                                        <TabPanel header="Documents">
                                            <DocumentComponent></DocumentComponent>
                                        </TabPanel>
                                    </TabView>
                                </Panel>
                            </div>
                        </div>
                    </Panel>
                </div>


            </div>
        );
    }
}
export default withRouter(candidateProfileComponent);
