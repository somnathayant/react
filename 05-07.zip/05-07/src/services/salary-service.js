class SalaryService {


    constructor() {

        this.salaryTypes = [
            {
                "candidateId": "61fdc646-09f7-497c-8d3f-5e54599142b8",
                "id": "18941a81-7ab4-4d8d-a8f4-3f94a0fb3460",
                "isHourly": "true",
                "isYearly": "false"
            }, {
                "candidateId": "61fdc646-09f7-497c-8d3f-5e54599142b8",
                "id": "18941a81-7ab4-4d8d-a8f4-3f94a0fb3460",
                "isHourly": "false",
                "isYearly": "true"
            }
        ];

    }
    async retrieveSalaryTypes() {
        return Promise.resolve(this.salaryTypes);
    }
}
export default SalaryService;