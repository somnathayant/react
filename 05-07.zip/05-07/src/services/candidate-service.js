
import axios from 'axios';
const qs = require("qs");
class CandidateService {

    constructor() {

    }
    async saveCandidate(candidate) {

        const options = {
            method: "post",
            headers: {
                "Content-Type": "application/json",
                'Authorization': 'Bearer ' + localStorage.getItem("TOKEN"),
            },
            data: JSON.stringify(candidate),
            url: "/resource/candidate/save"
        };

        axios(options)
            .then((response) => {
                alert("Candidate Registered");
            })
            .catch((err) => {
                console.log(err);
            });

    }
      getCandidates=async()=> {
        
        const options = {
            method: "get",
            headers: {
                "Content-Type": "application/json",
                'Authorization': 'Bearer ' + localStorage.getItem("TOKEN"),
            },
            url: "/resource/candidate/findAll"
        };
       
       const  candidateObject=await axios(options)
            .then((response) => {
                return response.data.output[0];

            })
            .catch((err) => {
               
                //alert("Un-Authorised");
            });
           
       return candidateObject;
    }
} export default CandidateService;