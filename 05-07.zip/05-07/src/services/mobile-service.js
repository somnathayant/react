class MobileService {


    constructor() {

        this.mobiles = [
            {
                "candidateId": "61fdc646-09f7-497c-8d3f-5e54599142b8",
                "id": "18941a81-7ab4-4d8d-a8f4-3f94a0fb3460",
                "countryCode": "+91",
                "mobileNumber": "9932472521"
            }, {
                "candidateId": "61fdc646-09f7-497c-8d3f-5e54599142b8",
                "id": "18941a81-7ab4-4d8d-a8f4-3f94a0fb3460",
                "countryCode": "+91",
                "mobileNumber": "9932472521"
            }
        ];

    }
    async retrieveMobiles() {
        return Promise.resolve(this.mobiles);
    }
}
export default MobileService;