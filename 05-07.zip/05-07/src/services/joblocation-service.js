class JobLocationService {


    constructor() {

        this.jobLocations = [
            {
                "candidateId": "112e013f-4145-44ec-a5c0-1cc35d9dc764",
                "locId": "fecc8117-a0bd-42c4-91ce-89486e2c6854",
                "area": "SOUTH",
                "state": "TX",
                "location": "asansol",
                "prefLocation": false,
                "currentLocation": true
            }, {
                "candidateId": "112e013f-4145-44ec-a5c0-1cc35d9dc764",
                "locId": "fecc8117-a0bd-42c4-91ce-89486e2c6854",
                "area": "SOUTH",
                "state": "TX",
                "location": "asansol",
                "prefLocation": false,
                "currentLocation": true
            }
        ];

    }
    async retrieveJoblocations() {
        return Promise.resolve(this.jobLocations);
    }
}
export default JobLocationService;