class SkillService {


    constructor() {

        this.skills = [
            {
                "candidateId": "dcf22aa6-8343-40a2-af26-35bdc2fbf591",
                "id": "1d98d1de-b60d-49fd-b2fd-b9d633a3cdec",
                "name": "Python",
                "proficientLevel": "Expert"
            }, {
                "candidateId": "dcf22aa6-8343-40a2-af26-35bdc2fbf591",
                "id": "1d98d1de-b60d-49fd-b2fd-b9d633a3cdec",
                "name": "Python",
                "proficientLevel": "Expert"
            }
        ];

    }
    async retrieveSkills() {
        return Promise.resolve(this.skills);
    }
}
export default SkillService;