class ExperienceService {


    constructor() {

        this.experiences = [
            {
                "candidateId": "112e013f-4145-44ec-a5c0-1cc35d9dc764",
               
                "title": "Executive Assistant Test",
                "summary": "<ul><li>Dealt with contacts and correspondence.</li><li>Managed suppliers, contractors and office systems.</li><li>Maintained handbooks, policies and practices, ensuring they were understood and adhered to by all staff.</li><li>Coordinated and project managed the office relocation and renovation.</li></ul>",
                "startDate": "01/01/2020",
                "endDate": "01/01/2023",
                "company": "Overflow Furnishings",
                "industry": "IT",
                "isCurrent": true
            }, {
                "candidateId": "112e013f-4145-44ec-a5c0-1cc35d9dc764",
                
                "title": "Executive Assistant Test",
                "summary": "<ul><li>Dealt with contacts and correspondence.</li><li>Managed suppliers, contractors and office systems.</li><li>Maintained handbooks, policies and practices, ensuring they were understood and adhered to by all staff.</li><li>Coordinated and project managed the office relocation and renovation.</li></ul>",
                "startDate": "01/01/2020",
                "endDate": "01/01/2023",
                "company": "Overflow Furnishings",
                "industry": "IT",
                "isCurrent": true
            }
        ];

    }
    async retrieveExperiences() {
        return Promise.resolve(this.experiences);
    }
}
export default ExperienceService;