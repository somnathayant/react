import React from 'react';
import { Redirect } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import FooterComponent from '../Footer/Footer.component';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Route, BrowserRouter as Router, Switch, Link } from 'react-router-dom';
import MenubarComponent from '../Menubar-Component/Menubar.component';
import { TabView, TabPanel } from 'primereact/tabview';
import { Panel } from 'primereact/panel';
import { DataTable } from 'primereact/datatable';
import { FileUpload } from 'primereact/fileupload';
import { Column } from 'primereact/column';
import { Dialog } from 'primereact/dialog';
import { Calendar } from 'primereact/calendar';
import JobLocationService from '../services/joblocation-service';
import { RadioButton } from 'primereact/radiobutton';
class JoblocationComponent extends React.Component {

    constructor(props) {
        super(props);
        this.jobLocationService = new JobLocationService();
        this.onAdd = this.onAdd.bind(this);
        this.onHide = this.onHide.bind(this);
        this.onUpdate = this.onUpdate.bind(this);
        this.actionOnUpdateTemplate = this.actionOnUpdateTemplate.bind(this);
        this.onDelete = this.onDelete.bind(this);
        this.actionOnDeleteTemplate = this.actionOnDeleteTemplate.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.handleAreaChange = this.handleAreaChange.bind(this);
        this.handleStateChange = this.handleStateChange.bind(this);
        this.handleLocationChange = this.handleLocationChange.bind(this);
        this.handlePrefLocationChange = this.handlePrefLocationChange.bind(this);
        this.handleCurrentLocationChange = this.handleCurrentLocationChange.bind(this);
        this.state = {
            visibleOn: false,
            visibleOff: true,
            displayResponsive: false,
            displayAdd: false,
            jobLocations: [],
            candidateId: '',
            locId: '',
            area: '',
            state: '',
            location: '',
            prefLocation: '',
            currentLocation: ''
        };
    }

    //handle Change methods
    handleAreaChange(e) {
        this.setState({ area: e.target.value });
    }
    handleStateChange(e) {
        this.setState({ state: e.target.value });
    } handleLocationChange(e) {
        this.setState({ location: e.target.value });
    } handlePrefLocationChange(e) {
        this.setState({ prefLocation: e.target.value });
    } handleCurrentLocationChange(e) {
        this.setState({ currentLocation: e.target.value });
    }

    //loading method
    componentDidMount() {
        this.jobLocationService.retrieveJoblocations().then(loc => {
            this.setState({
                jobLocations: loc
            });
        });
    }
    //method to display panel
    onAdd(name) {
        alert("add");
        this.setState({
            area: '',
            state: '',
            location: '',
            prefLocation: '',
            currentLocation: ''
        });
        let state = {
            [`${name}`]: true
        };

        this.setState(state);
    }

    //submit method
    onSubmit = (event) => {
        event.preventDefault();

        alert(this.state.currentLocation);
        alert(this.state.prefLocation);
      
        


        this.onHide('displayAdd');
        this.onHide('displayResponsive');
    }

    //method to display panel
    onUpdate(name, rowData) {
        alert(rowData.candidateId);
        alert(rowData.id);
        this.setState({
            candidateId: this.state.jobLocations[0].candidateId,
            locId: this.state.jobLocations[0].locId,
            area: this.state.jobLocations[0].area,
            state: this.state.jobLocations[0].state,
            location: this.state.jobLocations[0].location,
            prefLocation: this.state.jobLocations[0].prefLocation,
            currentLocation: this.state.jobLocations[0].currentLocation,
        });
        let state = {
            [`${name}`]: true
        };

        this.setState(state);
    }
    //hide panel
    onHide(name) {
        this.setState({
            [`${name}`]: false
        });
    }
    //shows pencil icon in datatable for update
    actionOnUpdateTemplate(rowData) {
        // alert(rowData.candidateId);
        return (
            <React.Fragment>
                <Button icon="pi pi-pencil" onClick={() => this.onUpdate('displayResponsive', rowData)} />
            </React.Fragment>
        );
    }
    onDelete(rowData) {
        alert(rowData.candidateId + "d");

    }
    //shows trash icon in datatable for delete
    actionOnDeleteTemplate(rowData) {
        // alert(rowData.candidateId);
        return (
            <React.Fragment>
                <Button icon="pi pi-trash" onClick={() => this.onDelete(rowData)} />
            </React.Fragment>
        );
    }

    render() {
        return (

            <div>
                
                <Button icon="pi pi-save" onClick={() => this.onAdd('displayAdd')} />
                <hr></hr>
                <Dialog header="Add JobLocation" visible={this.state.displayAdd} onHide={() => this.onHide('displayAdd')} breakpoints={{ '960px': '75vw' }} style={{ width: '50vw' }} >
                    <form onSubmit={this.onSubmit}>
                        <div className="p-grid">
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="candidate-id" disabled="true" value={this.state.candidateId} />
                                    <label htmlFor="candidate-id">Candidate Id</label>

                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="area" value={this.state.area} onChange={this.handleAreaChange} />
                                    <label htmlFor="area">Area</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="state" value={this.state.state} onChange={this.handleStateChange} />
                                    <label htmlFor="state">State</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="location" value={this.state.location} onChange={this.handleLocationChange} />
                                    <label htmlFor="location">Location</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <div className="p-field-radiobutton">
                                    <RadioButton inputId="currentLocation" name="currentLocation" value="true" onChange={this.handleCurrentLocationChange} checked={'true' === this.state.currentLocation} />

                                    <RadioButton inputId="currentLocation" name="currentLocation" value="false" onChange={this.handleCurrentLocationChange} checked={'false' === this.state.currentLocation} />
                                    <label htmlFor="currentLocation">Is It Current Location</label>
                                </div>

                            </div>
                            <div className="p-col-4 p-m-2">
                                <div className="p-field-radiobutton">
                                    <RadioButton inputId="prefLocation" name="prefLocation" value="true" onChange={this.handlePrefLocationChange} checked={'true' === this.state.prefLocation} />

                                    <RadioButton inputId="prefLocation" name="prefLocation" value="false" onChange={this.handlePrefLocationChange} checked={'false' === this.state.prefLocation} />
                                    <label htmlFor="prefLocation">Is It Preffred Location Location</label>
                                </div>

                            </div>
                            <div className="p-col-2 p-m-2">
                                <span className="p-float-label">
                                    <Button label="Submit" type="submit" icon="pi pi-save" className="p-button-info p-button-rounded" />
                                </span>
                            </div>

                        </div>
                    </form>
                </Dialog>

                <Dialog header="Update JobLocation" visible={this.state.displayResponsive} onHide={() => this.onHide('displayResponsive')} breakpoints={{ '960px': '75vw' }} style={{ width: '50vw' }} >
                    <form onSubmit={this.onSubmit}>
                        <div className="p-grid">
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="candidate-id" disabled="true" value={this.state.candidateId} />
                                    <label htmlFor="candidate-id">Candidate Id</label>
                                    <InputText id="locId" hidden="true" value={this.state.locId} />
                                 
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="area" value={this.state.area} onChange={this.handleAreaChange} />
                                    <label htmlFor="area">Area</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="state" value={this.state.state} onChange={this.handleStateChange} />
                                    <label htmlFor="state">State</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <span className="p-float-label">
                                    <InputText id="location" value={this.state.location} onChange={this.handleLocationChange} />
                                    <label htmlFor="location">Location</label>
                                </span>
                            </div>
                            <div className="p-col-4 p-m-2">
                                <div className="p-field-radiobutton">
                                    <RadioButton inputId="currentLocation" name="currentLocation" value="true" onChange={this.handleCurrentLocationChange} checked={'true' === this.state.currentLocation} />

                                    <RadioButton inputId="currentLocation" name="currentLocation" value="false" onChange={this.handleCurrentLocationChange} checked={'false' === this.state.currentLocation} />
                                    <label htmlFor="currentLocation">Is It Current Location</label>
                                </div>

                            </div>
                            <div className="p-col-4 p-m-2">
                                <div className="p-field-radiobutton">
                                    <RadioButton inputId="prefLocation" name="prefLocation" value="true" onChange={this.handlePrefLocationChange} checked={'true' === this.state.prefLocation} />

                                    <RadioButton inputId="prefLocation" name="prefLocation" value="false" onChange={this.handlePrefLocationChange} checked={'false' === this.state.prefLocation} />
                                    <label htmlFor="prefLocation">Is It Preffred Location Location</label>
                                </div>

                            </div>

                            <div className="p-col-2 p-m-2">
                                <span className="p-float-label">
                                    <Button label="Submit" type="submit" icon="pi pi-save" className="p-button-info p-button-rounded" />
                                </span>
                            </div>

                        </div>
                    </form>
                </Dialog>

                <Panel header="Educations" toggleable>
                    <div className="p-grid">
                        <div className="p-col-10 p-m-2">
                            <DataTable value={this.state.jobLocations}>
                                <Column field="area" header="Area"></Column>
                                <Column field="state" header="State"></Column>
                                <Column field="location" header="Location"></Column>
                                 <Column field="candidateId" body={this.actionOnUpdateTemplate} header="Update"></Column>
                                <Column field="candidateId" field="locId" body={this.actionOnDeleteTemplate} header="Delete"></Column>

                            </DataTable>
                        </div>

                    </div>
                </Panel>

            </div>
        );
    }
} export default withRouter(JoblocationComponent);
